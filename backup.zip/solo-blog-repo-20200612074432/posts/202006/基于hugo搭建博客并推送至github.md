title: 基于hugo搭建博客并推送至github
date: '2020-06-04 16:30:21'
updated: '2020-06-05 19:58:17'
tags: [hugo, 博客]
permalink: /articles/2020/06/04/1591259421107.html
---
![](ttps://b3logfile.com/bing/20180318.jpg?imageView2/1/w/960/h/540/interlace/1/q/10) 

# 基于hugo搭建博客并推送至github

## 提前准备

* [hugo安装包](https://github.com/gohugoio/hugo/releases)
* git

### 1：下载 Hugo

### 2：用Hugo来生成博客

```
hugo new site xx(文件夹名)
```

### 3：设置一个主题

[hugo主题选择地址](themes.gohugo.io)

选择主题名并进入并在themes文件夹下运行命令下载主题

### 4：在本地启动博客

```
hugo server -t (主题名) --buildDrafts### 5：写文章
hugo new post/blog.md 创建一个post的文件夹并创建blog的文件（目录为content）
```

### 6：将个人博客部署在远端服务器 注意网址名字必须是自己昵称。

```
lmlx66.github.io### 7：部署，命令会生成一个public的文件夹
hugo --theme=(主题名) --baseUrl="https://lmlx66.github.io/" --buildDrafts
```

### 8：public传入远端仓库（在public里面进行操作）

```
git init
git add .
git commit -m "我的hogu文件第一次提交"
```

```
9：进行关联,远端挂入git remote add origin https://github.com/lmlx66/lmlx66.github.io.git
```

### 10：推出

```
git push -u origin master
```

---

```
git push -u origin master -f   强制同步

删除关联库git remote rm origin

可以通过版如下命令进行代码合并【注：pull=fetch+merge]git pull --rebase origin master
```
