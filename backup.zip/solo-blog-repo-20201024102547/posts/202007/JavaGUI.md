title: JavaGUI
date: '2020-07-11 15:06:46'
updated: '2020-08-04 11:03:50'
tags: [Java, JavaSE]
permalink: /articles/2020/07/11/1594451206834.html
---
![](https://b3logfile.com/bing/20191218.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# GUI编程

怎么学？

* 这是什么？
* 它怎么玩？
* 我们如何运用

组件

* 窗口
* 弹窗
* 面板
* 文本框
* 列表框
* 按钮
* 图片
* 监听事件
* 鼠标
* 键盘事件
* 破解工具

## 1、简介

GUI核心技术：Swing、AWT

为什么不用：

1. 界面不美观。
2. 需要jre环境。

为什么我们要学习？

1. 可以写出自己想要的工具。
2. 工作时候，也可能需要维护到swing界面，概率极小！
3. 了解MVC架构，了解监听器！

## 2、AWT

### 2.1、Awt介绍

1. 包含了很多类和接口！GUI：图形用户界面编程。
2. 元素：窗口 ，按钮，文本框
3. java.awt

![](https://b3logfile.com/file/2020/07/solofetchupload7512942394767203966-002e4624.jpeg)

### 2.2组件和容器

#### 1、Frame

```java
package com.lixiang.lesson01;

import java.awt.*;

public class TestFrame {
    public static void main(String[] args){
        //Frame
        Frame frame = new Frame("我的第一个java图形界面窗口");
    
        //设置可见性
        frame.setVisible(true);
    
        //设置窗口大小
        frame.setSize(400,400);
    
        //设置背景颜色 Color
        frame.setBackground(Color.lightGray);
    
        //弹出的初始位置
        frame.setLocation(200,200);
    
        //设置大小固定
        frame.setResizable(false);
    }
}

```

问题：发现窗口关闭不掉，只能停止运行

尝试回顾封装

```Java
package com.lixiang.lesson01;

import java.awt.*;

public class TestFrame2 {
    public static void main(String[] args) {
        //展示多个窗口 bew
        MyFrame MyFrame1 = new MyFrame (100,100,200,200,Color.lightGray);
        MyFrame MyFrame2 = new MyFrame (100,100,200,200,Color.lightGray);
        MyFrame MyFrame3 = new MyFrame (100,100,200,200,Color.lightGray);
        MyFrame MyFrame4 = new MyFrame (100,100,200,200,Color.lightGray);
    }
}
class MyFrame extends Frame {
    static int id = 0;//可能存在多个窗口，我们需要要给计数器。
    public MyFrame(int x,int y,int w,int h,Color color){
        super("Myframe+"+(++id));
        setVisible(true);
        setBounds(x,y,w,h);
    }
}
```

#### 2、面板Panel

```java
package com.lixiang.lesson01;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/*
*
* Panel 可以看成是一个空间，但是不能单独存在。
*
 */
public class TestPanle {
    public static void main(String[] args) {
        Frame frame= new Frame ();
        //布局的概念

        Panel panel = new Panel();
        //设置布局

        frame.setLayout(null);
        //坐标

        frame.setBounds(300,300,500,500);
        frame.setBackground(Color.green);

        //设置坐标，先对于frame
        panel.setBounds(50,50,400,400);
        panel.setBackground(new Color(15, 193, 101));

        //frame.add(panel);添加panel
        frame.add(panel);

        frame.setVisible(true);

        //监听实践，监听窗口关闭 System,exit(0);
        //适配器模式
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                //结束程序
                System.exit(0);
            }
        });
    }
}
```

### 2.3布局管理器

* 流式布局Flowlayout

```java
package com.lixiang.lesson01;

import java.awt.*;

public class TestFlowLayoout {
    public static void main(String[] args) {
        Frame frame = new Frame();

        //组件-按钮
        Button button1 = new Button("button1");
        Button button2 = new Button("button2");
        Button button3 = new Button("button3");
    
        //按键位置
        frame.setLayout(new FlowLayout());
        frame.setLayout(new FlowLayout(FlowLayout.LEFT));//左
        frame.setLayout(new FlowLayout(FlowLayout.RIGHT));//右

        frame.setSize(200,200);

        //添加按钮
        frame.add(button1);
        frame.add(button2);
        frame.add(button3);
        frame.setVisible(true);
}
```

* 五点式布局

```java
package com.lixiang.lesson01;

import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TasteBorderayout {
    public static void main(String[] args) {
        Frame frame = new Frame("TestBorderLayout");


        Button east = new Button("East");
        Button west = new Button("West");
        Button south = new Button("South");
        Button north = new Button("north");
        Button center= new Button("Center");

        frame.add(east,BorderLayout.EAST);
        frame.add(west,BorderLayout.WEST);
        frame.add(south,BorderLayout.SOUTH);
        frame.add(north,BorderLayout.NORTH);
        frame.add(center,BorderLayout.CENTER);

        frame.setSize(200,200);
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
    }
}
```

* 表格布局 Grid

```Java
package com.lixiang.lesson01;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestGridLayout {
    public static void main(String[] args) {
        Frame frame = new Frame("TestBorderLayout");


        Button btn1 = new Button("btn1");
        Button btn2 = new Button("btn2");
        Button btn3 = new Button("btn3");
        Button btn4 = new Button("btn4");
        Button btn5= new Button("btn5");
        Button btn6= new Button("btn6");

        frame.setLayout(new GridLayout(3,2));

        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);
        frame.add(btn4);
        frame.add(btn5);
        frame.add(btn6);

        frame.pack();//java函数   自动布局
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
    }
}
```

#### Homework

![](https://b3logfile.com/file/2020/07/solofetchupload5269623195593239446-e3f10c46.jpeg)

```java
package com.lixiang.lesson01;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class HomeWork {
    public static void main(String[] args) {
        //总窗
        Frame frame = new Frame();
        frame.setLayout(new GridLayout(2,1));
        frame.setBounds(400,300,300,400);
        frame.setBackground(Color.green);
        frame.setVisible(true);

        //四个面板
        Panel p1 = new Panel(new BorderLayout());
        Panel p2 = new Panel(new GridLayout(2,1));
        Panel p3 = new Panel(new BorderLayout());
        Panel p4 = new Panel(new GridLayout(2,2));

        //按钮
        //上面
        p1.add(new Button("East-1"),BorderLayout.EAST);
        p1.add(new Button("West-1"),BorderLayout.WEST);
        p2.add(new Button("p2-btn-1"));
        p2.add(new Button("p2-btn-2"));
        p1.add(p2,BorderLayout.CENTER);
        //下面
        p3.add(new Button("East-2"),BorderLayout.EAST);
        p3.add(new Button("West-2"),BorderLayout.WEST);
        p4.add(new Button("p4-btn-1"));
        p4.add(new Button("p4-btn-2"));
        p4.add(new Button("p4-btn-3"));
        p4.add(new Button("p4-btn-4"));
        p3.add(p4,BorderLayout.CENTER);

        //放入面板
        frame.add(p1);
        frame.add(p3);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
    }
}
```

### 2.4事件监听

事件监听：当某个事情发生的时候，干什么。

```java
package com.lixiang.lesson02;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestActionEvent {
    public static void main(String[] args) {
        //按下按钮，触发一些事件。
        Frame frame = new Frame();
        frame.setSize(1000,1000);
        frame.setLocation(400,400);
        Button button = new Button("wdnmd");
        //需要addActionListener（）需要要给ActionListener,所以我们需要构造一个ActionListener
        MyActionListener myActionListener = new MyActionListener();
        button.addActionListener(myActionListener);
        frame.add(button,BorderLayout.CENTER);
        frame.pack();
        windowClose(frame);
        frame.setVisible(true);

    }

    //关闭窗体事件
    private static void windowClose(Frame frame){
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
    }
}
class MyActionListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        System.exit(0);
    }
}
```

多个按钮，实现同一个接口

```java
package com.lixiang.lesson02;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestActionEvent2 {
    public static void main(String[] args) {
        //俩个按钮，实现同一个接口
        ///开始 停止
        Frame frame = new Frame("开始-停止");
        MyMonitor myMonitor = new MyMonitor();
        Button b1 = new Button("start");
        Button b2 = new Button("stop");

        b1.addActionListener(myMonitor);
        b2.addActionListener(myMonitor);

        frame.add(b1,BorderLayout.NORTH);
        frame.add(b2,BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
    }
}
class MyMonitor implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("按钮被点击了：nsg"+e.getActionCommand());
    }
}
```

### 2.5输入框

```java
package com.lixiang.lesson02;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestText01 {
    public static void main(String[] args) {
        // 启动！
        new MyFrame();
    }
}
class MyFrame extends Frame {
    public MyFrame(){
        TextField textField = new TextField();
        add(textField);
        setSize(400,400);
        setLocation(100,100);
        //监听文本框输入的文字
        MyActionListener2 myActionListener2 = new MyActionListener2();
        //按下enter 就会触发这个输入框里面的事件
        textField.addActionListener(myActionListener2);

        //设置替换编码
        textField.setEchoChar('*');

        setVisible(true);
        pack();
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
    }
}
class MyActionListener2 implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        TextField field=(TextField) e.getSource();//获得一些资源,返回了一个对象。
        System.out.println(field.getText());//获得输入文本框
        field.setText(null);//设置回车就清空文本
    }
}
```

### 2.6简易计算器，组合+内部类回顾！

oop原则：组合，大于继承！

```java
package com.lixiang.lesson02;
/**
 * 项目：简易计算器
 * 作者：坏银
 * 日期：20/7/4
 * 版本：v1.0
 */
import org.w3c.dom.Text;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class TestCalc {
    public static void main(String[] args) {
        new Calculator();
    }
}
//计算类
class Calculator extends Frame{
    public Calculator(){
        //3个文本框
        TextField num1 = new TextField(10);//字符数
        TextField num2 = new TextField(10);//字符数
        TextField num3 = new TextField(20);//字符数

        //1个按钮
        Button button = new Button("=");

        button.addActionListener(new MyCalculatorListener(num1,num2,num3));
        //1个标签
        Label label = new Label("+");

        //布局
        setLayout(new FlowLayout());

        add(num1);
        add(label);
        add(num2);
        add(button);
        add(num3);

        //自动布局
        pack();
        //启用关闭按钮
        addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
        setVisible(true);
    }
}
//监听器类
class MyCalculatorListener implements ActionListener{
    //获取三个变量
    private TextField num1,num2,num3;
    public MyCalculatorListener(TextField num1, TextField num2 , TextField num3){
        this.num1 = num1;
        this.num2 = num2;
        this.num3 = num3;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        //1.获得加数与没被加数
        int n1 = Integer.parseInt(num1.getText());
        int n2 = Integer.parseInt(num2.getText());

        //2.运算加法，放到第三个框
        num3.setText(""+(n1+n2));

        //3，清楚前面俩个框
        num1.setText(null);
        num2.setText(null);
    }
}
```

完全改造为面向对象

```java
package com.lixiang.lesson02;
/**
 * 项目：简易计算器
 * 作者：坏银
 * 日期：20/7/4
 * 版本：v2.0
 */
import org.w3c.dom.Text;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class TestCalc {
    public static void main(String[] args) {
        new Calculator().loadFrrame();
    }
}
//计算类
class Calculator extends Frame{
    //属性
    TextField num1,num2,num3;

    //方法
    public void loadFrrame(){
        //3个文本框
        num1 = new TextField(10);//字符数
        num2 = new TextField(10);//字符数
        num3 = new TextField(20);//字符数

        //1个按钮
        Button button = new Button("=");

        button.addActionListener(new MyCalculatorListener(this));
        //1个标签
        Label label = new Label("+");

        //布局
        setLayout(new FlowLayout());

        add(num1);
        add(label);
        add(num2);
        add(button);
        add(num3);

        //自动布局
        pack();
        //启用关闭按钮
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
        setVisible(true);
    }
    //监听器类
    class MyCalculatorListener implements ActionListener{
        //获取计算器这个对象，在一个类中组合另外的一个类。
        Calculator calculator = null;
        public MyCalculatorListener(Calculator calculator){
            this.calculator = calculator;
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            //1.获得加数与没被加数
            int n1 = Integer.parseInt(calculator.num1.getText());
            int n2 = Integer.parseInt(calculator.num2.getText());

            //2.运算加法，放到第三个框
            calculator.num3.setText(""+(n1+n2));

            //3，清楚前面俩个框
            num1.setText(null);
            num2.setText(null);
        }
    }
}  
```

内部类

```Java
package com.lixiang.lesson02;
/**
 * 项目：简易计算器
 * 作者：坏银
 * 日期：20/7/5
 * 版本：v2.1
 */
import org.w3c.dom.Text;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class TestCalc {
    public static void main(String[] args) {
        new Calculator().loadFrrame();
    }
}
//计算类
class Calculator extends Frame{
    //属性
    TextField num1,num2,num3;

    //方法
    public void loadFrrame(){
        //3个文本框
        num1 = new TextField(10);//字符数
        num2 = new TextField(10);//字符数
        num3 = new TextField(20);//字符数

        //1个按钮
        Button button = new Button("=");

        button.addActionListener(new MyCalculatorListener());
        //1个标签
        Label label = new Label("+");

        //布局
        setLayout(new FlowLayout());

        add(num1);
        add(label);
        add(num2);
        add(button);
        add(num3);

        //自动布局
        pack();
        //启用关闭按钮
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }
        });
        setVisible(true);
    }
    //监听器类
    //内部类最大的好处，就是可以畅通无阻的访问外部类的属性和方法。
    private class MyCalculatorListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            //1.获得加数与没被加数
            int n1 = Integer.parseInt(num1.getText());
            int n2 = Integer.parseInt(num2.getText());

            //2.运算加法，放到第三个框
            num3.setText(""+(n1+n2));

            //3，清楚前面俩个框
            num1.setText(null);
            num2.setText(null);
        }
    }
}
```

### 2.7画笔

```Java
package lesson03;

import java.awt.*;

public class TestPanint {
    public static void main(String[] args) {
        new MyPaint().loadFrame();
    }
}
class MyPaint extends Frame {
    public void loadFrame(){
        setBounds(200,200,600,500);
        setVisible(true);
    }
    //画笔
    @Override
    public void paint(Graphics g) {
        //画笔，需要有颜色，可以画画
        g.setColor(Color.lightGray);
        //圆
        g.drawOval(100,100,100,100);
        g.fillOval(100,100,100,100);//实心的圆
        //正方形
        g.setColor(Color.green);
        g.fillRect(150,150,200,200);
        //画笔用完，还原到最初的颜色
    
    }
}
```

### 2.8鼠标监听

当点击鼠标按钮时，有三个监听器方法可以调用：①鼠标按下时调用mousePressed；②鼠标被释放时调用mouseReleased；③关注鼠标的最终点击事件时调用mouseClicked。鼠标点击可以由mouseClicked过程报告，该方法是MouseListener接口的一部分。通常大部分应用程序只对鼠标点击事件感兴趣，而对鼠标移动及拖动并不感兴趣，但是鼠标移动及拖动事件又经常发生，因此，鼠标移动与拖动事件定义在一个MouseMotionListener接口中。

### 2.9窗口监听

新建类关闭窗口按键

```java
package com.lixiang.Lesson05;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestWindow {
    public static void main(String[] args) {
        new WindowFrame();
    }
}
class WindowFrame extends Frame{
    public WindowFrame(){
        setBackground(Color.lightGray);
        setBounds(200,200,400,400);
        setVisible(true);
        addWindowListener(new MyWindowListenter());
    }
}

class MyWindowListenter extends WindowAdapter{
    @Override
    public void windowClosing(WindowEvent e) {
        super.windowClosing(e);
        System.exit(0);//正常退出
        //通过点击按钮隐藏setVisible(false);
    }

}
```

使用匿名内部类关闭窗口

```java
package com.lixiang.Lesson05;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TestWindow {
    public static void main(String[] args) {
        new WindowFrame();
    }
}
class WindowFrame extends Frame{
    public WindowFrame(){
        setBackground(Color.lightGray);
        setBounds(200,200,400,400);
        setVisible(true);
        this.addWindowListener(
                //匿名内部类
                new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        super.windowClosing(e);
                        System.exit(0);
                    }

                    @Override
                    public void windowOpened(WindowEvent e) {
                        super.windowOpened(e);
                    }

                    @Override
                    public void windowIconified(WindowEvent e) {
                        super.windowIconified(e);
                    }

                    @Override
                    public void windowDeiconified(WindowEvent e) {
                        super.windowDeiconified(e);
                    }

                    @Override
                    public void windowActivated(WindowEvent e) {
                        super.windowActivated(e);
                    }

                    @Override
                    public void windowDeactivated(WindowEvent e) {
                        super.windowDeactivated(e);
                    }

                    @Override
                    public void windowStateChanged(WindowEvent e) {
                        super.windowStateChanged(e);
                    }

                    @Override
                    public void windowGainedFocus(WindowEvent e) {
                        super.windowGainedFocus(e);
                    }

                    @Override
                    public void windowLostFocus(WindowEvent e) {
                        super.windowLostFocus(e);
                    }
                }
        );
    }
}
```

### 2.10键盘监听

```java
package com.lixiang;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Lesson06 {
    public static void main(String[] args) {
        new KeyFrame();
    }
}
class KeyFrame extends Frame{
    public KeyFrame(){
        setBounds(100,200,300,400);
        setVisible(true);

        //键盘监听内部类
        this.addKeyListener(
                new KeyAdapter() {
            //键盘按下
            @Override
            public void keyPressed(KeyEvent e) {
                //获得键盘按下的键是哪一个
                int KeyCode = e.getKeyCode();//获得键盘是哪个健
                if(KeyCode == KeyEvent.VK_UP){
                    System.out.println("你按下了上键");
                }
            }
        });
        //窗口监听内部
        this.addWindowListener(
                new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        super.windowClosing(e);
                        System.exit(0);
                    }
                }
        );
    }
}
```

## 3、Swing

### 3.1、窗口，面板

```java
package com.lixiang.Lesson07;

import javax.swing.*;
import java.awt.*;

public class JFrameDemo {

    //init()；初始化
    public void init(){
        //顶级窗口
        JFrame jf = new JFrame("这是一个JFram窗口");
        jf.setVisible(true);
        jf.setBounds(100,100,200,200);
        jf.setBackground(Color.white);

        //设置文字Jlabel
        JLabel label = new JLabel("天哪");
        label.setHorizontalAlignment(SwingConstants.CENTER);//居中
        jf.add(label);


        //关闭事件
        jf.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
    }
    public static void main(String[] args) {
        //建立一个窗口
        new JFrameDemo().init();
    }
}
```

### 3.2、弹窗

JDialog,用来被弹出，默认就有关闭事件。

```java
package com.lixiang.Lesson08;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//主窗口
public class DialogDemo extends JFrame{
    public static void main(String[] args) {
        new DialogDemo();
    }
    public DialogDemo(){
        this.setVisible(true);
        this.setSize(700,500);


        //JFrame 放东西，容器
        Container container = this.getContentPane();
        //绝对布局
        container.setLayout(null);
        //按钮
        JButton button = new JButton("点击弹出一个对话框");//创建
        button.setBounds(30,30,200,60);

        //点击这个按钮的时候，弹出一个窗口
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //弹窗
                new MyDialogDemo();
            }
        });
        container.add(button);
    }
}

//弹窗的窗口
class MyDialogDemo extends JDialog{
    public MyDialogDemo() {
        this.setVisible(true);
        this.setBounds(100,100,500,500);
        //this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        Container container = this.getContentPane();
        container.setLayout(null);

        container.add(new Label("坏银"));

    }
}
```

### 3.3、标签/图片

label

```java
new Lavel("xxx");
new JLavel("xxx");
```

图片标签

```java
package com.lixiang.Lesson10;

import javax.swing.*;
import java.awt.*;
import java.net.URL;


public  class ImageIconDemo extends JFrame{
    public ImageIconDemo() {
        //获取图片的地址
        JLabel label = new JLabel();
        URL url = ImageIconDemo.class.getResource("1.jpg");//图片链接

        ImageIcon imageIcon = new ImageIcon(url);//图片对象
        label.setIcon(imageIcon);
        label.setHorizontalAlignment(SwingConstants.CENTER);

        Container container = getContentPane();
        container.add(label);
        setVisible(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBounds(100,100,200,200);
    }
    public static void main(String[] args) {
        new ImageIconDemo();
    }
}
```

```java
public static JPanel CreateNorthPanel(){
    JPanel p = new JPanel();
    p.setLayout(null);//取消默认布局
    p.setPreferredSize(new Dimension(0,135));//设置面板尺寸
    //背景图片
    ImageIcon i =new ImageIcon("src/images/back.jpg");//添加背景图片
    JLabel background = new JLabel(i);
    background.setBounds(0,0,440,i.getIconHeight());//设置背景图片位置，尺寸
    p.add(background);//背景图片加入到面板中
    //顶部面板的退出按钮
    JButton out = new JButton(new ImageIcon("src/images/close2_normal.jpg"));
    out.setBounds(403,0,25,26);//退出按钮位置
    out.setRolloverIcon(new ImageIcon("src/images/close_hover.jpg"));//鼠标移动时更改图标为红×
    out.setBorderPainted(false);//取消按钮边框效果
    p.add(out);
    return p;
}
```

### 3.4、面板

JPanel同Panel

JScrollPanel，下拉框

```java
package Lesson17;

import javax.swing.*;
import java.awt.*;

public class JScrollDemo extends JFrame {
    public JScrollDemo(){
        Container container = this.getContentPane();

        //文本域
        JTextArea textArea = new JTextArea(20 ,50);
        textArea.setText("坏银哦");

        //Scroll面板
        JScrollPane scrollPane = new JScrollPane(textArea);
        container.add(scrollPane);

        this.setBounds(100,100,400,400);
        this.setVisible(true);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new JScrollDemo();
    }
}
```

### 3.5、按钮

获取类包图片：

```java
URL url = 类.class.getResource("1.jpg");
```

* 图片按钮

```java
package Lesson19;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class JButtonDemo01 extends JFrame {
    public JButtonDemo01() {
        Container container = this.getContentPane();
        //将图片编程图标
        URL resource = JButtonDemo01.class.getResource("tx.jpg");
        Icon icon = new ImageIcon(resource);

        //图标放在按钮上
        JButton button = new JButton();
        button.setIcon(icon);
        button.setToolTipText("图片按钮");
        //add
        container.add(button);

        this.setVisible(true);
        this.setSize(500,300);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new JButtonDemo01();
    }
}
```

```java
package Lesson20;

import javax.swing.*;
import java.awt.*;

public class Demo extends JFrame{
    public  void init(){
        JFrame jf = new JFrame();
        jf.setVisible(true);
        jf.setSize(500,300);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setLayout(new BorderLayout());
        //单选框
        JRadioButton radioButton1 = new JRadioButton("JB1");
        JRadioButton radioButton2 = new JRadioButton("JB2");
        JRadioButton radioButton3 = new JRadioButton("JB3");

        //由于单选框只能选一个，分组，一个组中只能选一个(单选即不分组)
        ButtonGroup g = new ButtonGroup();
        g.add(radioButton1);
        g.add(radioButton2);
        g.add(radioButton3);

        jf.add(radioButton1,BorderLayout.NORTH);
        jf.add(radioButton2,BorderLayout.CENTER);
        jf.add(radioButton3,BorderLayout.SOUTH);
   }

    public static void main(String[] args) {
        new Demo().init();
    }
}
```

* 复选

```java
package Lesson20;

import javax.swing.*;
import java.awt.*;

public class Demo extends JFrame{
    public  void init(){
        JFrame jf = new JFrame();
        jf.setVisible(true);
        jf.setSize(500,300);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setLayout(new BorderLayout());
        //多选框，即不分组
        JRadioButton radioButton1 = new JRadioButton("JB1");
        JRadioButton radioButton2 = new JRadioButton("JB2");
        JRadioButton radioButton3 = new JRadioButton("JB3");

        jf.add(radioButton1,BorderLayout.NORTH);
        jf.add(radioButton2,BorderLayout.CENTER);
        jf.add(radioButton3,BorderLayout.SOUTH);
   }

    public static void main(String[] args) {
        new Demo().init();
    }
}
```

### 3.6、列表

* 下拉框

```java
package Lesson21;

import Lesson20.Demo;

import javax.swing.*;
import java.awt.*;

public class Demo1 extends JFrame {
    public Demo1() throws HeadlessException {

        Container container = this.getContentPane();

        JComboBox status = new JComboBox();//下拉框方法

        status.addItem(null);
        status.addItem("12312312312");
        status.addItem("123123123");
        status.addItem("123123123");

        container.add(status);

        this.setVisible(true);
        this.setSize(300,400);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new Demo1();
    }
}
```

* 列表框

```java
package Lesson21;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class Demo2 extends JFrame{
    public Demo2() throws HeadlessException {

        Container container = this.getContentPane();

        //生成列表内容
        //String[] contents = {"1","2","3"};

        Vector contents = new Vector();
        //列表中的内容
        JList jList = new JList(contents);

        contents.add("张三");
        contents.add("李四");
        contents.add("王五");

          container.add(jList);

        this.setVisible(true);
        this.setSize(300,400);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new Demo2();
    }
}

```

#### 应用场景

* 先择地区，或者一些单个选项。
* 列表，展示信息，一般是动态扩容。

### 3.7、文本框

* 文本框

```java
package Lesson21;

import javax.swing.*;
import java.awt.*;
import java.util.Vector;

public class Demo3 extends JFrame{
    public Demo3() throws HeadlessException {

        Container container = this.getContentPane();

        JTextField textField = new JTextField("hello");
        JTextField textField1 = new JTextField("world",20);

        container.add(textField,BorderLayout.NORTH);
        container.add(textField1,BorderLayout.SOUTH);

        this.setVisible(true);
        this.setSize(300,400);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new Demo3();
    }
}
```

* 密码框

```java
package Lesson21;

import javax.swing.*;
import java.awt.*;

public class Demo4 extends JFrame{
    public Demo4() throws HeadlessException {

        Container container = this.getContentPane();

        JPasswordField passwordField = new JPasswordField();
        passwordField.setEchoChar('+');

        container.add(passwordField);

        this.setVisible(true);
        this.setSize(300,400);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new Demo4();
    }
}
```

* 文本域（JTextArea）

```java
package Lesson21;

import javax.swing.*;
import java.awt.*;

public class JScrollDemo extends JFrame {

    public JScrollDemo() {
        Container c = this.getContentPane();

        //文本域
        JTextArea textArea  = new JTextArea(20,50);
        textArea.setText("坏银的文本域");

        //Scroll面板
        JScrollPane sp = new JScrollPane(textArea);
        c.add(sp);

        this.setVisible(true);
        this.setBounds(100,100,300,400);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new JScrollDemo();
    }
}
```
