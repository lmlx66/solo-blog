title: solo博客介绍
date: '2020-06-04 16:28:01'
updated: '2020-06-04 16:28:01'
tags: [solo, 博客]
permalink: /articles/2020/06/04/1591259281333.html
---
![](ttps://b3logfile.com/bing/20200326.jpg?imageView2/1/w/960/h/540/interlace/1/q/10)

# Solo

## 小而美的博客系统，为未来而构建

## ['soʊloʊ]，n.独奏

* Solo 是一款小而美的博客系统，专为程序员设计
* 我们有一个活跃的[小众社区](https://hacpai.com/b3log)，文章可以推送到社区让更多人看到
* [《Solo 从设计到实现》](https://hacpai.com/article/1537690756242)剖析这款系统的方方面面
* 第一个版本发布于 2010 年，永不断更 😼

## 💡 简介

---

[Solo](https://link.hacpai.com/forward?goto=https%3A%2F%2Fsolo.b3log.org)是一款小而美的开源博客系统，专为程序员设计。Solo 有着非常活跃的[社区](https://hacpai.com/)，可将文章作为帖子推送到社区，来自社区的回帖将作为博客评论进行联动（具体细节请浏览 [B3log 构思 - 分布式社区网络](https://hacpai.com/article/1546941897596)）。

> 这是一种全新的网络社区体验，让热爱记录和分享的你不再感到孤单！

## 🗃案例

[案例链接点这里](https://hacpai.com/top/solo)

## ✨ 功能

[Markdown 编辑器](https://link.hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2FVanessa219%2Fvditor)支持三种编辑模式：所见即所得 / 即时渲染 / 分屏预览

[标签聚合分类](https://hacpai.com/article/1558320086126)

自定义导航链接

随机文章 / 相关文章 / 置顶 / 更新提醒

自定义文章永久链接 / 签名档

配置站点 SEO 参数 / 公告 / 页脚

代码高亮 / 数学公式 / 流程图 / 五线谱

[多皮肤，多端适配](https://link.hacpai.com/forward?goto=https%3A%2F%2Fsolo.b3log.org%2F%23themes)

多语言 / 国际化

友情链接管理

多用户写作，团队博客

[Hexo / Jekyll / Markdown 导入](https://hacpai.com/article/1498490209748)

SQL / JSON / Markdown 导出

Atom / RSS / Sitemap

CDN 静态资源分离，可配置 jsDelivr CDN 分发

[拉取 GitHub 仓库和自动备份](https://hacpai.com/article/1557238327458)

[内置 HTTPS+CDN 文件存储](https://hacpai.com/article/1559928188793)

[支持生成导出静态站点](https://hacpai.com/article/1579053576274)，用于发布 GitHub Pages

***转载自：[Solo 用户指南 ](https://hacpai.com/article/1492881378588)***

*链接：[https://hacpai.com/article/1492881378588](https://hacpai.com/article/1492881378588)*

*来源：黑客派*

*协议：CC BY-SA 4.0 [https://creativecommons.org/licenses/by-sa/4.0/](https://creativecommons.org/licenses/by-sa/4.0/)*

---

## 相关链接：

### Solo

[solo主页](https://solo.b3log.org/?utm_source=hacpai.com)

[solo_github下载地址](https://github.com/88250/solo/releases?utm_source=hacpai.com)

[solo安装](https://hacpai.com/article/1492881378588#---%E5%AE%89%E8%A3%85)

[solo静态搭建](https://hacpai.com/article/1589816039114)

[solo安装步骤with CSDN](https://blog.csdn.net/a724888/article/details/79975343)

[教你搭建 solo 博客站（像我酱紫的）](https://hacpai.com/article/1589816039114)

### 基于solo改造的bolo博客介绍：

[bolo](https://doc.stackoverflow.wiki/web/#/7?page_id=46)

[bolo github](https://github.com/adlered/bolo-solo/releases)
