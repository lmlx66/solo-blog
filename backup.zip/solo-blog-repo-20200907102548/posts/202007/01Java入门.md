title: 01Java入门
date: '2020-07-05 22:39:35'
updated: '2020-07-05 22:40:00'
tags: [Java, JavaSE]
permalink: /articles/2020/07/05/1593959975413.html
---
![](https://b3logfile.com/bing/20190401.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 1、java出生

图形界面程序（Applet）

java 2 标准版（JSE2）：占领坐面

java 2 移动版（J2ME）：占领手机

==java 2 企业版（J2EE）：占领服务器==

基于java开发了许多平台，系统，工具

* 构建工具：Ant，Maven，JeKins
* 应用服务器：Tomcat，Jetty，Jboss，Websphere，Weblogic
* Web开发：Struts，Spring，Hibernate，myBatis
* 开发工具：Eclipse，netbean，intellij idea，Jbuilder
* .....

2006：Hadoop（大数据领域）

2008：Android（手机端）

# 2、java特性和优势

* 简单性
* 面向对象：一切皆对象
* 可移植性：一次编译，处处运行
* 高性能：即时编译
* 分布式
* 动态性：反射机制
* 多线程
* 安全性
* 健壮性

# 3、java三大版本

* Write Once 、 Run Anywhere
* JavaSE：标准版（桌面程序，控制台开发...）
* JavaMe:嵌入式开发（手机，小家电...）几乎没人学。
* JavaEE:E企业级开发（Web端，服务器开发...）

# 4、JDK、JRE、JVM

* JDK：Java Development Kit
* JRE：Java Runtime Environment（运行环境）
* JVM：Java Virtual Machine（Java虚拟机）

# 5、Java安装环境

## 1.如何卸载

1.环境变量JAVA_HOME找到jdk地址，并且连包删除。

2.删除JAVA_HOME。

3.删除path下关于java的目录。

4.Java -version

## 2.安装jdk

1.安装对应版本的JDK8（新版本了解特性）

2.**记住安装的路径**

3.配置环境变量

1. 我的电脑-->右键->属性
2. 环境变量-->JAVA_HOME（地址为jdk目录）
3. 配置path变量(%JAVA_HOME%\bin)(%JAVA_HOME%\jre\bin)

4.检查是否安装成功dos：java -version查看java版本（如果出现版本号就安装成功了）

# 6、HelloWorld

```java
package lesson01;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("HelloWord");
   }
}
```

编译：javac.java文件,会生成class文件

运行；运行class文件，java class文件

### 可能遇到的问题

1.每个单词的大小写，不能出现问题，**Java是大小写敏感的**

2.尽量使用因为

3.文件名和有main方法的类名要保证一致。

4.符号使用了中文

# 7、Java程序运行机制

* 编译型
* 解释型

Java=>源文件（*.Java文件）-->java编译器-->字节码（*.class文件）-->类装载器-->字节码校验器-->解释器-->操作系统平台

# 8、开发工具IDEA安装

IDE为集成开发环境，用于提供程序开发环境的应该程序。，一般包括代码编辑器、编译器、调试器和图形用户界面等工具。

[IDEA官网](https://www.jetbrains.com/)

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java学习/4.jpg)
