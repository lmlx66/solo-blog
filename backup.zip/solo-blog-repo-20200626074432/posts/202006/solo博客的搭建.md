title: solo博客的搭建
date: '2020-06-04 16:05:07'
updated: '2020-06-06 16:27:49'
tags: [博客, solo]
permalink: /articles/2020/06/04/1591257907424.html
---
![](ttps://b3logfile.com/bing/20190130.jpg?imageView2/1/w/960/h/540/interlace/1/q/10)

# 序言

solo博客系统是用java语音开发的博客系程序，在这里非常感谢开发这一系统的带佬。同时，也为我的成功搭建，写一篇文章庆祝一下。后文则是对于这个solo系统的一个介绍以及安装方法。

## 相关环境

* 阿里云ECS轻量级服务器
* ubuntu server_18_04
* Solo安装包
* jdk1.8
* Dockers
* MySQL

# 具体步骤

### 服务器

1：申请云服务器（本坏银于2020年新冠肺炎期间白嫖了阿里云服务器六个月，同时，其他服务器也可以是哟个。腾讯云学生套餐十块钱一个月）

* 2：选择系统（我这边选择了经常使用的Ubuntu Server 18_04）
* 3:创建云服务器登录方式选择密码方式(方便上传文件)
* 4:配置创建好的云服务器安全组，配置如下

### 申请域名

---

* 1：查询合适的域名
* 2：购买域名（.xyz以及.top域名新用户都很便宜，一块钱一年。.top域名三年五十多可以说非常的实惠了，同时要注意，服务器以及域名最好是同一个公司出售给你的。否则在解析以及备案是有可能出现问题）
* 3：备案。使用域名解析国内的服务器需要备案，通常需要三十天左右，具体情况查看域名提供商的文档。

### 安装博客服务

1：登陆服务器（mac可以直接打开终端），Windows系统需要安装可以使用SSH的软件（自行百度），在二零一九年十二月的时候Windows更新了一个自带软件叫做power shell的软件，其可以使用ssh（可连接远端连接linux系统的服务），直接搜索这一软件或者在某文件夹按住Shift健加右键，即可打开power shell。

```
ssh -p 22 系统用户名@公网IP地址
例如
ssh -p 22 root@10.22.10.2
```

2：安装过程中先使用更新apt包的索引

```
sudo apt-get update
```

3：安装java环境（我这边安装的是1.8）同时，也可以从电脑上传或者直接下载最新版安装。

```
sudo apt-get install openjdk-8-jdk
```

4:安装docker

```
sudo apt-get install docker.io
```

5:安装VIM

```
sudo apt-get install vim
```

6:使用docker安装solo以及MySQL

```
# 下载mysql 镜像
sudo docker pull mysql
# 启动镜像  MYSQL_ROOT_PASSWORD=mysql的root密码
docker run -d --name mysql-5.7 --network=host -v /var/lib/mysql:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=root  mysql:5.7 --character-set-server=utf8mb4 --collation-server=utf8mb4_general_ci
# 登录mysql（提前可能需要安装mycli这个工具）
mycli
# 如果登录提示错误，执行以下可能管用
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
# 创建数据库
CREATE DATABASE solo DEFAULT CHARACTER SET utf8mb4  DEFAULT COLLATE utf8mb4_general_ci
# 退出mycli工具
quit


# 下载solo博客镜像
sudo docker pull b3log/solo

# 启动solo镜像（注意的是\这一换行符有可能会报错，打命令是去掉\即可，如果还是报错就去掉空行）
# JDBC_PASSWORD(mysql的密码)  
# listen_port(启动端口)  
# server_scheme(访问协议) 
# server_host(请求的地址) 
# server_port(请求的端口)
 docker run --detach --name solo --network=host \
        --env RUNTIME_DB="MYSQL" \
        --env JDBC_USERNAME="root" \
        --env JDBC_PASSWORD="root" \
        --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
        --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
        b3log/solo --listen_port=8080 --server_scheme=https --server_host=adongs.com --server_port=80
# 查看启动结果
sudo docker ps
# 结果如下就表示启动成功(STATUS表示启动成功)
```

## 配置域名和代理

1：申请 SSL(笔者在腾讯云申请的免费 SSL,[第三方免费 SSL](https://link.hacpai.com/forward?goto=https%3A%2F%2Fadongs.com%2Farticles%2F2019%2F08%2F12%2F1565606243689.html))

2：下载 SSL 到本地，并解压

3：上传 SSL 到云服务器

```
scp -r SSL文件目录 系统用户名@公网i:/home/系统用户名
```

4：配置nginx

```
#登录云服务器,执行如下
sudo vim /etc/nginx/sites-enabled/default
#将文本里面的内容全删除,拷贝如下文本内容
#修改server_name为自己的域名
#修改ssl_certificate和ssl_certificate_key的文件路径
#修改proxy_pass为自己的域名和solo启动端口
server {
listen    443 ssl;
server_name www.xxx.com,xxx.com;
ssl_certificate  /etc/nginx/ssl/xxx.crt;
ssl_certificate_key /etc/nginx/ssl/xxx.key;
location / {
proxy_pass http://www.xxx.com:8080;
}
}
server {
listen     80;
listen     [::]:80;
server_name www.xxx.com,xxx.com;
return 301 https://hostrequest_uri;
}
# 保存并退出后重启nginx

nginx -s reload
```

## 调试

打开自己的域名进行调试即可，倘若没有域名或者还没有备案的话，可以输入IP访问

```
Ip：开放端口
#例如
10.22.10.2:8080
```

## 参考链接

[从零开始安装 solo 博客 ](https://hacpai.com/article/1565021959471)

[solo安装官方步骤](https://hacpai.com/article/1492881378588#---%E5%AE%89%E8%A3%85)
