title: windows中使用ssh（powershell）
date: '2020-06-05 11:24:57'
updated: '2020-06-30 21:35:59'
tags: [ssh, Linux]
permalink: /articles/2020/06/05/1591327497139.html
---
![](https://b3logfile.com/bing/20200210.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# powershell介绍

大家知道，在Windows中是不能使用cmd进行ssh远程访问Linux主机的，在2019年二十日更新的一个Windows 10版本中，新增加的一个自动软件叫powershell，这个软件可以使用集成了Linux相关命令以及shh等命令。

## 打开方式

* 在开始按键中找到windows powershell这个软件，或者直接查找。
* 在某一文件夹按住Shift加右键，即可找到一 `使用powershell打开 选项。`

## 总结

其实，powersell并不完善，甚至可以说是垃圾。但是，在着急的情况下还是可以临时使用的。并且有总比没有好。

# 使用ssh过程中常见的问题

* 1.在使用ssh连接到外网Linux主机时，有一个文件.ssh/known_hosts的文件，是**known_hosts是记录远程主机的公钥**的文件，之前重装个系统，而保存的公钥还是未重装系统的系统公钥，在ssh链接的时候首先会验证公钥，如果公钥不对，那么就会报错。

解决办法：

* 、将known_hosts文件中的与登录错误的IP的公钥删除即可，下图就是我的218机子的公钥（实则是之前系统的公钥），然后将其删除，再ssh 登录 great 登录成功了。
* 2、将known_hosts文件中的内容清空即可，但不建议使用此方法，里面还保存有其他机子的公钥。
* 3、使用shh-keygen 命令（强烈建议使用此方法）
  比如我们要将172.16.152.209的公钥信息清除，使用命令（请自己将172.16.152.209替换成自己的IP或域名）：

```
ssh-keygen -R 主机IP
```
