title: 06Java面向对象3
date: '2020-07-07 11:45:15'
updated: '2020-07-07 11:45:15'
tags: [Java, JavaSE]
permalink: /articles/2020/07/07/1594093515520.html
---
# 1、instanceof和类型转换

## instancof

==instanceof判断一个对象是什么类型！==

```java
System.out.println(x instanceof y);//能不能编译通过
```

取决于关系!

```java
package Lesson10;

public class Application {
    public static void main(String[] args) {

        //object > String
        //Object > Person > Teacher
        //Object > Person > Student
        Object object = new Student();

        System.out.println(object instanceof Student);//true
        System.out.println(object instanceof Person);//true
        System.out.println(object instanceof Object);//true
        System.out.println(object instanceof Teacher);//false
        System.out.println(object instanceof String );//false
        System.out.println("================");

        Person person = new Student();

        System.out.println(object instanceof Student);//true
        System.out.println(object instanceof Person);//true
        System.out.println(object instanceof Object);//ture
        System.out.println(object instanceof Teacher);//flase
        System.out.println(object instanceof String );//flase
        System.out.println("==============");

        Student student = new Student();

        System.out.println(object instanceof Student);//true
        System.out.println(object instanceof Person);//true
        System.out.println(object instanceof Object);//ture
        System.out.println(object instanceof Teacher);//flase
        System.out.println(object instanceof String );//flase
    }
}
```

## 类型转化

```java
package Lesson10;

public class Person {
    public void run(){
        System.out.println("run");
    }
}
```

```java
package Lesson10;

public class Student extends Person {
    public void go(){
        System.out.println("go");
    }
}
```

```java
package Lesson10;

public class Application {
    public static void main(String[] args) {

        //类型之间的转化:基本类型转化 高低 64 32 16 8
        //父类和子类   低转高     高转低需要强制转化
        //高                     低
        Person obj = new Student();
        //student.go();报错//人类使用学生类的方法go，报错
        //因此我们需要讲student将这个对象转化成Student类型，我们就可以使用Student类型的方法!

        ((Student) obj).go();
    }
}
```

```java
package Lesson10;


public class Application {
    public static void main(String[] args) {

        Student student = new Student();
        student.go();
        Person person = student;
    }
}
```

### 注意：

1. 父类引用指向子类对象
2. 把子类转化为父类，向上转型
3. 把父类转化为子类，向下转型：强制转换
4. 方便方法的调用，减少重复的代码！

==子类转化父类可能会丢失方法。==

# 2、static关键字

```java
package Lesson11;

public abstract class Student {

    private static int age;//静态的变量  多线程！
    private double score;//非静态的变量
    //方法：
    public void run(){

    }
    public  static void go(){

    }
    public static void main(String[] args) {
        Student s1 = new Student();

        System.out.println(Student.age);
        System.out.printf(String.valueOf(s1.age));
        System.out.println(s1.score);
        go();
        s1.run();
    }
}
```

## 代码块

```java
package Lesson11;

public class Person {
    /*
    {
        //代码块（匿名代码块）
    }
    static{
        //静态代码块
    }
     */
    //1
    {
        //赋初始值
        System.out.println("匿名代码块");
    }
    //2
    static {
        //只执行一次
        System.out.println("静态代码块");
    }
    //3
    public Person(){
        System.out.println("构造方法");
    }

    public static void main(String[] args) {
        Person person1 = new Person();
        System.out.println("==========");
        Person person2 = new Person();
    }
}
```

## 静态导入包

```java
package Lesson11;

//静态导入包
import static java.lang.Math.random;
public class Test {
    public static void main(String[] args) {
        System.out.println(random());
    }
}
```

# 3、抽象类

abstract来修饰的类，就是抽象类了。

1. 不能new抽象类，只能靠子类实现它：约束！
2. 抽象方法必须在抽象类中。
3. 抽象类中可以写普通方法。
4. 抽象的抽象：约束

```java
package Lesson12;

//abstract 抽象类：类extends   单继承     （但是接口可以多继承）
public abstract class Action {

    //约束~有人帮我实现
    //abstract，抽象方法，只有方法名字，没有方法实现。
    public abstract void doSomething();

  
}
```

```java
package Lesson12;

//抽象类的所有方法，继承了他的子类，都必须要实现它的方法。
public  class A extends Action{
    @Override
    public void doSomething() {

    }
}
```

# 4、接口

**接口:只有规范！自己无法写方法。专业的约束！约束和实现分离：面向接口编程！**

**接口的本质是契约**

申明接口的关键字是：**interface**

继承接口的关键字是：**implements**

接口只写方法名，不写实现

```java
package Lesson13;

public interface TimeService {
    void timer();
}
```

```java
package Lesson13;

//interface 定义关键字，接口都需要有实现类
public interface UserService {

    //常量 PUblic static final
    int AFE = 99;

    //接口中的所有定义其实都是抽象的 public abstract.
    void add(String name);
    void delete(String name);
    void update(String name);
    void query(String name);
}
```

```java
package Lesson13;

//实现了接口的类，就需要重写接口中的方法

//侧面实现多继承
public class UserServiceImpl implements UserService,TimeService{
    @Override
    public void add(String name) {

    }

    @Override
    public void delete(String name) {

    }

    @Override
    public void update(String name) {

    }

    @Override
    public void query(String name) {

    }

    @Override
    public void timer() {

    }
}
```

## 接口的作用

1. 约束
2. 定义一些方法，让不同的人实现
3. public abstract
4. public static final
5. 接口不能被实例化，接口没有构造方法（不能new）
6. implements可以实现多个接口
7. 必须要重写接口中的方法

# 5、内部类

## 成员内部类

outer

```java
package Lesson14;

public class Outer {

    private int id=10;
    public void out(){
        System.out.println("这是外部类方法");
    }
    class Inner{
        public void in(){
            System.out.println("这是内部类的方法");
        }

        //获得外部的私有属性
        public void getID(){
            System.out.println(id);
        }
    }
}
```

```java
package Lesson14;

public class Application {
    public static void main(String[] args) {
        Outer outer = new Outer();
        //通过这个外部类来实例化内部类
        Outer.Inner inner = outer.new Inner();
        inner.in();
    }
}
```

## 静态内部类

顾名思义，加static

## 局部内部类

即：套娃

```java
package Lesson14;

public class Outer {
  
    //局部内部类
    public void method(){
      
        class Inner{
            public void in(){
              
            }
        }
    }
}
```

## 匿名内部类

不写名字的内部类

```java
package Lesson14;

public class Test {
    public static void main(String[] args) {

        //没有名字初始化类，不用讲实例保存到变量中
        new Apple().eat();

        new UserService() {
            @Override
            public void hello() {
              
            }
        };
    }
}
class Apple{
    public void eat(){
        System.out.println("1");
    }
}
interface UserService{
    void hello();
}
```
