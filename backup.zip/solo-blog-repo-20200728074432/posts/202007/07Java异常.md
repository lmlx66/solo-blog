title: 07Java异常
date: '2020-07-07 17:13:01'
updated: '2020-07-07 17:13:01'
tags: [Java, JavaSE]
permalink: /articles/2020/07/07/1594113181685.html
---
1. 异常

### 什么是异常？

实际工作中，遇到的情况不可能是非常完美的。比如：你写的某个模块，用户输入不一定符合你的要求、你的程序要打开某个文件。这个文件可能不存在或者文件格式不对。你要读取数据库的数据，数据可能为空。我们的程序再运行，内存或者磁盘可能满了等等。

软件程序在运行过程中，就有可能遇到上面的情况，我们叫做异常：**Exception（例外）**。

异常发生在程序行期间，它影响了正常的程序执行流程。

## 简单分类

检查性异常：用户错误或问题引起的异常，这是程序员无法预见的。

运行时异常：运行时异常是可能被程序员避免的异常。可以是在编译时被忽略。

错误ERROR：错误不是异常，而是脱离程序员控制的问题。错误在代码中通常被忽略。例如：当栈溢出时，错误就发生了，并且在编译时候也检查不到。

## 异常体系结构

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java学习/7.jpg)

# 2、Error和Exception

**Error**是灾难性的致命的错误，是程序无法控制和处理的，当出现这些异常时，java虚拟机（JVM）一般会选择终止线程

**Exception**通常情况下是可以被程序处理的，并且在程序中应该尽可能的去处理这些异常。

# 3、捕获和抛出异常

异常处理五个关键字：**try、catch、finally、throw、throws**

catch(想要捕获的异常类型！)最高的为，Throwable！同时，也可以使用多个catch，最大的异常写在最下面，即上面成功捕获了，下面就不会捕获了。

### 快捷键=>选中后Ctry+Alt+t，可以快速包裹起来。

```java
package Lesson15;

public class Test {
    public static void main(String[] args) {
        int a = 1;
        int b = 0;

        try
        {//try监控区域
            System.out.print(a/b);
        }
        catch (ArithmeticException e)
        {//捕获异常
            System.out.println("程序出现异常，变量不能为零");
        }
        finally
        {//最后执行
            System.out.println("finally");
        }
        //finally可以不要finally，假设IO，资源，关闭
    }
}
```

# 4、自定义异常以及经验小结

## 自定义异常

使用java内置的异常类可以描述在编程时出现的大部分异常情况。除此之外，用户还可以自定义异常。用户自定义异常类，只需要继承Exception类即可。

```java
package Lesson16;

public class MyException extends Exception{

    //传递数字》10；
    private int detail;

    public MyException(int a) {
        this.detail = a;
    }

    //toString:异常的打印信息
    @Override
    public String toString() {
        return "MyException{" +
                "detail=" + detail +
                '}';
    }
}
```

```java
package Lesson16;

public class Test {
    public static void main(String[] args) {
        try {
            test(11);
        } catch (MyException e) {
            System.out.println("MyException=>"+e);
        }
    }
    //可能会存在异常的方法
    static void test(int a) throws MyException {
        System.out.println ("传递的参数为"+a);
        if(a>10){
            throw new MyException(a);
        }
        System.out.println("OK");
    }
}
```

## 经验总结

* 处理运行时异常时，采用逻辑去合理规避同时辅助try-catch处理
* 在多重catch块后面，可以加一个catch（Exception）来处理可能会被遗漏的异常
* 对于不确定的代码，也可以加上try-catch，处理潜在的异常
* 尽量去处理异常，切忌只是简单地调用printStachTrace（）去打印输出
* 具体如何处理异常，要根据不同地业务需求和异常类型去决定
* 尽量添加finally语句块去释放占用地资源
