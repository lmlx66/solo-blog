title: git常用命令
date: '2020-06-04 16:13:43'
updated: '2020-06-04 16:26:16'
tags: [git, 学习笔记]
permalink: /articles/2020/06/04/1591258423585.html
---
![](ttps://b3logfile.com/bing/20190604.jpg?imageView2/1/w/960/h/540/interlace/1/q/10) 

### 1：git初始化

> `Git init `初始化仓库以后会生成一个.git的文件隐藏文件，他就是你的本地仓库，他会记录你所有的行为。
> `git status `可以查看当前仓库的状态信息。

### 2：加入暂存区

> `git add <filename(文件名)> `可以将某一个文件暂存区
>
> `git add . `将所有文件加入暂存区
>
> `git reset `退出暂存区

### 3：提交变更到本地仓库

> `Git commit -m <message(对提交的描述)>`
>
> `git log`可以查看日志

### 4：自定义命令git的安装目录中有个gitconfig在alias中可以设置

### 5：回退版本reset

> `git reset `ID可以查看版本日志
>
> `git reflog`可以查看所有操作记录
>
> 回到最新的commit，可以直接 `git pull`

#### 常用添加：

`````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````
--hard 不保存所有变更

--soft 保留变更且变更内容处于Staged（变绿）

--mixed 保留变更且变更内容为Modified（变红）
`````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````````

### 6：master（分支）

> `git checkout -b <name新分支名字> <template以哪个分支或者commit为模板>`可以创建新的分支
>
> 假如是远端的仓库 `git checkout -b`

> `git checkout` 分支名 可以切换到其他分支
>
> `git branch `可以查看所有分支，高亮是当前所处的分支。
>
> git checkout <branchName> 就可以不查找id来切换版本

### 7：merge （合并）

> `git merge ` 合并分支变更

### 8：remote（远程仓库）

> `Git push -setup-stream origin（远端仓库）` （masterName）

设置上流分支

将远程仓库的分支作为本地的分支的上流分支

输入以后的的效果就是在远程仓库中增加了一个分支

> `git fetch` 拉取远程仓库信息，只是获知，但是本地不会复制过来

### 9：git pull

> 它可以将云端与本地仓库同步

### 10：rebase变基

> （重新排列commit=base）
