title: 02Java基础
date: '2020-07-06 09:40:40'
updated: '2020-08-04 09:29:01'
tags: [Java, JavaSE]
permalink: /articles/2020/07/06/1593999640193.html
---
![](https://b3logfile.com/bing/20191204.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Java基础语法

## 1、注释、标识符、关键字

* 平常编写代码，当项目结构一旦复杂起来，我们就需要用到注释。
* 注释并不会被执行，是给我们写代码的人看的
* ==书写注释是一个非常好的习惯==
* ==平时写代码一定要注意规范==

Java中的注释有三种：

* 单行注释

```java
//(单行注释)
//输出helloworld
```

* 多行注释

```java
/*（使用俩个符号包起来）*/
/*
多行注释
多行注释
多行注释
*/
```

* 文档注释

```java
//JavaDoc:文档注释 /** */
/**
*作者；坏银
*版本：V1.0
*....
*/
```

## 2、标识符和关键字

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java学习(基础语法)/1.jpg)

==Java所有的组成部分都需要名字。类名、变量名以及方法名都被称为标识符==

## 3、数据类型

强类型语音

* 要求变量的使用要严格符合规定，所有变量都必须先定义才能使用。安全，但是运行速度慢（Java）

弱类型语音

* 不要求变量的使用要严格符合规定（VB、JS）

Java的数据类型分为俩大类

基本数据类型（primitive type）

引用类型（reference type）

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java学习(基础语法)/4.jpg)

```java
package lesson01;

public class Demo01 {
    public static void main(String[] args) {
        //整数
        int num1 = 10;
        byte num2 = 20;
        short num3 = 30;
        long num4 = 30L;//long类型要在数字后面加个L

        //小数：浮点数
        float num5 = 50.1F;//float类型要在数字后面加一个F
        double num6 = 3.141592654;

        //字符
        char name = '坏';
        //字符串，String不是关键字，类
        String namea = "坏银"；

        //布尔值：是非
        boolean flag = true;
        //boolean flag = false;
    }
}
```

## 4、数据类型扩展以及面试题

```
package lesson01;

public class Demo02 {
    public static void main(String[] args) {
        //整数拓展   进制   二进制0b   十进制   八进制0   十六进制0x
        int i = 10;
        int i2 = 010;//八进制
        int i3 = 0x10;//十六进制0x

        System.out.println(i);
        System.out.println(i2);
        System.out.println(i3);
        System.out.println("=========================================");

        //浮点数拓展
        //银行业务怎么表示？
        //float和double都有问题的
        //float 有限，离散，舍入误差，大约，接近但不等于
        //double
        //最好避免完全使用浮点数进行比较
        //最好避免完全使用浮点数进行比较
        //最好避免完全使用浮点数进行比较
        //==========================
        //使用BigDecimal  数学工具类表示
        //==========================

        float f = 0.1f;//0.1
        double d = 1.0 / 10;//0.1
        System.out.println(f == d);//fasle
        System.out.println(f);
        System.out.println(d);
        System.out.println("=========================================");

        //=============================
        //字符拓展
        //=============================
        char c1 = 'a';
        char c1 = '中';

        System.out.println(c1);
        System.out.println((int) c1);
        System.out.println(c2);
        System.out.println((int) c1);
        //ASCLL码：字符的本质还是数字
        //（a = 97  b = 65）

        //U0000 UFFFF
        char c3 = '\u0061';
        System.out.println(c3);//a
        System.out.println("====================");
        //转义字符
        // \t 制表
        // \n 换行
        //==========================
        //
        String sa = new String("hello world");
        String sb = new String("hello world");
        System.out.println(sa == sb);

        String sc = "hello world";
        String sd = "hello world";
        System.out.println(sc == sd);
        //可以看见，第一是不相等的，第二是相等的

        //布尔值
        ///Boolean flag = true;
        //if (flag == true) {}
        //if (flag) {}
    }
}
```
