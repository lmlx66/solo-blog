title: Java多线程
date: '2020-07-13 20:15:49'
updated: '2020-08-04 09:21:33'
tags: [Java, JavaSE]
permalink: /articles/2020/07/13/1594642549203.html
---
![](https://b3logfile.com/bing/20180929.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 1、线程（Process）和进程（Thread）

程序是指令和数据的有序集合，其本身没有任何运行的含义，是一个静态的概念。

而进程则是执行程序的一次执行过程，它是一个动态的概念。是系统资源分配的单位。

通常在一个进程中可以包含若干个线程，当然一个进程中至少有一个线程，不然没有存在的意义。线程是中央处理器调度和执行的单位。

注意：很多多线程是模拟出来的，真正的多线程是指由多核CPU，如服务器。如果是模拟出来的多线程，即在一个CPU的情况下，在同一个时间点，CPU只能执行一个代码，因为切换的很快，所以就有同行执行的错觉。

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/1.jpg)

# 2、继承Thread类

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/2.jpg)

自定义线程类继承Thread类

重写run()方法，编写线程执行体

创建线程对象，调用start()方法启动线程

```java
package Lesson01;

//总结：注意，线程开启不一定立即执行，由CPU调度执行
public class TestThread1 extends  Thread{
    @Override
    public void run() {
        //run方法线程体
        for(int i = 0 ;i<20;i++){
            System.out.println("我在看代码！"+i);
        }
    }

    public static void main(String[] args) {
        //main线程，主线程

        //创建线程对象
        TestThread1 testThread1 = new TestThread1();
        //调用start方法开启线程
        testThread1.start();
        //交替执行的

        for(int i =0;i<200;i++){
            System.out.println("我在学习多线程"+i);
        }
    }
}
```

**注意：**

调用的是start方法而不是run方法，在第一节图解中可以看到，如果调用run方法，是先执行开辟线程再执行主线程，而start方法是重写开辟一条线程并由CPU调度执行顺序。

```java
package Lesson01;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URL;

//练习Thread，实现多线程同步下载图片
public class TestThread2 extends Thread{

    private String url;//图片地址
    private String name;//保存的文件名

    public TestThread2(String url,String name){
        this.url = url;
        this.name = name;
    }

    @Override
    public void run() {
        WebDownLoader webDownLoader = new WebDownLoader();
        webDownLoader.downloader(url,name);
        System.out.println("下载了文件名为："+name);
    }

    public static void main(String[] args) {
        TestThread2 t1 = new TestThread2("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/1.jpg","1.jpg");
        TestThread2 t2 = new TestThread2("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/2.jpg","2.jpg");
        TestThread2 t3 = new TestThread2("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/2.jpg","3.jpg");

        t1.start();
        t2.start();
        t3.start();
    }
}

//下载器
class WebDownLoader{
    //下载方法
    public void downloader(String url,String name){
        try {
            FileUtils.copyURLToFile(new URL(url),new File(name));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("IO异常，downloader方法出现问题");
        }
    }
}
```

# 3、实现Runnable接口

定义MyRunnable类实现Runnable接口

实现run()方法，编写线程执行体

创建线程对象，调用start()方法启动线程

**对比继承Thread类**

```java
package Lesson01;

//实现runnable接口，重写run方法，执行线程需要丢入runnable接口实现类，调用start方法
public class TestThread3 implements Runnable{

    @Override
    public void run() {
        //run方法线程体
        for(int i =0 ;i<50;i++){
            System.out.println("我在看代码"+i);
        }
    }

    public static void main(String[] args) {
        //创建runnable接口的实现类对象
        TestThread3 testThread3 = new TestThread3();

        //创建线程对象，通过线程对象来开启我们的线程，代理
        //Thread thread = new Thread(testThread3);
        //thread.start();
        new Thread(testThread3).start();

        for(int i =0;i<200;i++){
            System.out.println("我在学习多线程"+i);
        }
    }
}
```

### 下载图片

```java
package Lesson01;


import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URL;

//练习Thread，实现多线程同步下载图片
public class TestThread4 extends Thread{

    private String url;//图片地址
    private String name;//保存的文件名

    public TestThread4(String url,String name){
        this.url = url;
        this.name = name;
    }

    @Override
    public void run() {
        WebDownLoader webDownLoader = new WebDownLoader();
        webDownLoader.downloader(url,name);
        System.out.println("下载了文件名为："+name);
    }

    public static void main(String[] args) {
        TestThread2 t1 = new TestThread2("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/1.jpg","1.jpg");
        TestThread2 t2 = new TestThread2("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/2.jpg","2.jpg");
        TestThread2 t3 = new TestThread2("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/2.jpg","3.jpg");

        new Thread(t1).start();
        new Thread(t2).start();
        new Thread(t3).start();
    }
}
//下载器
class WebDownLoader{
    //下载方法
    public void downloader(String url,String name){
        try {
            FileUtils.copyURLToFile(new URL(url),new File(name));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("IO异常，downloader方法出现问题");
        }
    }
}
```

# 4、总结Thread类和Runnable接口

继承Thread类

* 子类继承Thread类具备多线程能力
* 启动线程：子类对象.start()
* **不建议使用：避免opp单继承局限性**

实现Runnable接口

* 实现接口Runnable具有多线程能力
* 启动线程：传入目标对象+Thread对象.start()
* 推荐使用：避免单继承局限性，灵活方便，方便同一个对象被多个线程使用

买票:

```就ava
package Lesson02;

//多个线程同时操作同一个对象
//麦火车票的例子

//发现问题：多个线程操作同一个资源的情况下，线程不安全了。
//出现了同一张票被不同的俩个人抢到了
public class TestThread implements Runnable{

    //票数
    private int tickerNums = 10;
    @Override
    public void run() {
        while(true){
            if(tickerNums<=0){
                break;
            }

            System.out.println(Thread.currentThread().getName()+"--->拿到了第"+tickerNums--+"张票");//Thread.currentThread().getName()获取当前线程名字
        }
    }

    public static void main(String[] args) {
        TestThread ticket = new TestThread();

        new Thread(ticket,"小明").start();
        new Thread(ticket,"老师").start();
        new Thread(ticket,"黄牛").start();

    }
}
```

# 5、案例：龟兔赛跑

1. 赛道距离
2. 判断比赛是否结束
3. 打印出胜利者
4. 龟兔赛跑开始
5. 兔子需要睡觉
6. 乌龟赢了比赛

```java
package Lesson02;

import javax.swing.*;

public class Race implements Runnable{
    //胜利者
    private static String Winner;
    @Override
    public void run() {
        for (int i = 0; i <= 100; i++) {

            //模拟兔子睡觉
            if(Thread.currentThread().getName().equals("兔子")&&i%10==0){
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            //判断比赛是否结束
            boolean flag = gameOver(i);

            //如果比赛结束，停止程序
            if(flag){
                break;
            }

            System.out.println(Thread.currentThread().getName()+"-->跑了"+i+"步");
        }
    }

    //判断完成比赛
    private boolean gameOver(int steps){
        //判断是否有胜利者
        if(Winner!=null){//存在胜利者
            return true;
        }
        if(steps>=100){
            Winner = Thread.currentThread().getName();
            System.out.println("Winner is : "+Winner);
            return true;
        }
        return false;
    }

    public static void main(String[] args) {
        Race race = new Race();

        new Thread(race,"兔子").start();
        new Thread(race,"乌龟").start();
    }
}
```

# 6、实现Callable接口

1. 实现Callable接口，需要返回值类型
2. 重写call方法，需要抛出异常
3. 创建对象
4. 创建执行服务:ExecutorService ser = Executors.newFixedThreadPool(1);
5. 提交执行：Future\<boolean\>result1 = ser.submit(ti);
6. 获取结果：boolean r1 = result1.get()
7. 关闭服务：ser.shutdownNow();

### 改造下载图片

```java
package Lesson02;

import Lesson01.TestThread2;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.*;

public class TestCallbale implements Callable<Boolean> {
    private String url;//图片地址
    private String name;//保存的文件名

    public TestCallbale(String url,String name){
        this.url = url;
        this.name = name;
    }

    @Override
    public Boolean call() {
        WebDownLoader webDownLoader = new WebDownLoader();
        webDownLoader.downloader(url,name);
        System.out.println("下载了文件名为："+name);
        return true;
    }

    public static void main(String[] args) {
        TestCallbale t1 = new TestCallbale("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/1.jpg","1.jpg");
        TestCallbale t2 = new TestCallbale("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/2.jpg","2.jpg");
        TestCallbale t3 = new TestCallbale("https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/2.jpg","3.jpg");

        //1.创建执行服务:创建线程池
        ExecutorService ser = Executors.newFixedThreadPool(3);

        //2. 提交执行：Future\<boolean\>result1 = ser.submit(ti);
        Future<Boolean> r1 = ser.submit(t1);
        Future<Boolean> r2 = ser.submit(t2);
        Future<Boolean> r3 = ser.submit(t3);

        //3. 获取结果：boolean r1 = result1.get()
        try {
            boolean rs1 = r1.get();
            boolean rs2 = r2.get();
            boolean rs3 = r3.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        //4. 关闭服务：ser.shutdownNow();
        ser.shutdownNow();
    }
}
//下载器
class WebDownLoader{
    //下载方法
    public void downloader(String url,String name){
        try {
            FileUtils.copyURLToFile(new URL(url),new File(name));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("IO异常，downloader方法出现问题");
        }
    }
}
```

### Callable接口总结：

* 可以定义返回值
* 可以抛出异常

# 7、静态代理

```java
package Lesson02;

import javax.swing.*;
/*
    静态代理模式总结：
    真实角色和代理角色都要实现同一个接口

    //好处：
        //代理对象可以做很多做不了的事情‘
        //真实对象专注做自己的事情

    说明：
    你要结婚，找婚庆公司
    你继承结婚这件事情的接口，写出了你要结婚做的事情。
    婚庆公司同时继承结婚的接口，做完应该你做的事情，不如婚前布置这些。
    最后调用他们的方法，把你这个结婚对象插进去。拼接事情。
 */
public class StacticProxy {

    public static void main(String[] args) {


        //You you = new You();
        //WeddingCompany weddingCompany = new WeddingCompany(you);
        //weddingCompany.Marry();
        //上面三行也可写成
        new WeddingCompany(new You()).Marry();
    }
}

//你结婚
class You implements Marry{

    @Override
    public void Marry() {
        System.out.println("结婚咯！");
    }
}

//婚庆公司:代理，帮你结婚
class WeddingCompany implements Marry{

    //真实目标目标对象
    private Marry target;

    public WeddingCompany(Marry target) {
        this.target = target;
    }

    @Override
    public void Marry() {
        before();
        this.target.Marry();//这就是真实角色
        after();
    }

    private void after() {
        System.out.println("结婚之后，收尾款");
    }

    private void before() {
        System.out.println("结婚之前，布置现场");
    }
}

//结婚接口
interface Marry{
    //结婚方法
    void Marry();

}
```

思考与多线程的关系;

run（）方法内容就是真实对象，Runnable接口和Thread类就是一个代理，这个代理帮本体完成了多线程的这一共功能。

# 8、Lamda表达式

为什么要使用？

* 避免匿名内部类定义过多
* 可以让你的代码看起来很简介
* 去掉没有意义的代码，只留下核心逻辑

函数式接口：

任何接口，如果只包含唯一一个抽象方法，那么他就是一个函数式接口。

```java
public interface Runnable{
    public abstract void run();
}
```

对于函数式接口，我们可以通过lambda表达式来创建该接口的对象。

对比：

### 普通方法

```java
package Lesson03;

public class TestLambda1 {
    public static void main(String[] args) {
        ILike like = new Like();
        like.lambda();
    }
}
//1.定义一个函数式接口
interface ILike{
    void lambda();
}
//2.实现类
class Like implements ILike{
    @Override
    public void lambda() {
        System.out.println("i like lambda!");
    }
}
```

### 静态内部类

一个类的方法只使用一次，不如把他丢入需要实现的类里面

```java
package Lesson03;
//使用静态内部类
public class TestLambda1 {
    public static void main(String[] args) {
        new Like().lambda();
    }
    //2.实现类
    static class Like implements ILike{
        @Override
        public void lambda() {
            System.out.println("i like lambda!");
        }
    }
}
//1.定义一个函数式接口
interface ILike{
    void lambda();
}
```

### 局部内部类

```java
package Lesson03;
//使用局部内部类
public class TestLambda1 {
    public static void main(String[] args) {


        //2.局部实现类：写在调用该类的方法里面
        class Like implements ILike{
            @Override
            public void lambda() {
                System.out.println("i like lambda!");
            }
        }
        //一定要放在下面，才可以调用
        new Like().lambda();
    }

}
//1.定义一个函数式接口
interface ILike{
    void lambda();
}
```

### 匿名内部类

必须是函数式接口

```java
package Lesson03;
//使用匿名内部类
public class TestLambda1 {
    public static void main(String[] args) {
        //匿名内部类，没有类的名称，必须借助接口或者父类
        ILike like = new ILike() {
            @Override
            public void lambda() {
                System.out.println("I like lambda!");
            }
        };
       like.lambda();
    }

}
//1.定义一个函数式接口
interface ILike{
    void lambda();
}
```

### Lamda表达式

```java
package Lesson03;
//使用lambda表达式
public class TestLambda1 {
    public static void main(String[] args) {
        ILike like = () -> {
            System.out.println("I like lambda");
        };

    }

}
//1.定义一个函数式接口
interface ILike{
    void lambda();
}
```

```java
package Lesson03;

public class Lambad {
    public static void main(String[] args) {
        /*1、方法一
        ILove love =(int a)->{
            System.out.println("i love you ->"+a);
        };*/
        /*2、方法二
        ILove love = a-> {
            System.out.println("i love you ->"+a);
        };*/
        //3、方法三（只有一行的时候使用）
        ILove love = a->System.out.println("i love you ->"+a);
        love.love(520);
    }


}
interface  ILove{
    void love(int a);
}
```

# 9、线程状态

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/4.jpg)

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java多线程/5.jpg)


| 方法 | 说明 |
| :-: | :-: |
| setPriority(int newPriority) | 更改线程优先级 |
| static void sleep(long millis) | 指定毫秒数让当前正在执行的线程休眠 |
| void join() | 等待该线程终止（插队） |
| static vid tield() | 暂停该 线程，并执行其他线程(礼让) |
| void interrupt() | 停止线程，不建议使用 |
| boolean isAlive() | 当前现在状态 |

## 1.停止线程：

```java
package Lesson04;
/*
    1.建议线程正常停止：利用次数，不建议死循环
    2.建议使用标志位：设置一个标志位
    3.不要使用stop或者destroy等过时的方法
 */
public class TestStop implements Runnable
{
    //1.设置标识位
    private boolean flag = true;
    @Override
    public void run() {
        int i = 1;
        while(flag){
            System.out.println("run....Thread"+i++);
        }
    }
    //设置一个公开的方法停止线程，转换标志位
    public void stop(){
        this.flag = false;
    }

    public static void main(String[] args) {
        TestStop testStop = new TestStop();

        new Thread(testStop).start();

        for (int i = 0; i < 1000; i++) {
            if(i==900){
                testStop.stop();
                System.out.println("线程停止了");
            }
        }
    }
}
```

## 2.线程休眠（sleep）

sleep指定当前线程阻塞的毫秒数，一千毫秒=一秒

sleep存在异常InterruptedException

sleep时间达到后线程进入就绪状态

sleep可以模拟网络延迟，倒计时等等

没有给对象都有一个锁，sleep不会释放锁

```java
package Lesson04;

public class TestSleep2 {
    public static void main(String[] args) {
        try {
            tenDown();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void tenDown() throws InterruptedException {
        int num = 10;
        while(true){
        Thread.sleep(1000);
        System.out.println(num--);
        if(num <= 0){
            break;
        }
        }
    }
}
```

## 3.线程礼让（yield）

当前线程停止，但并不阻塞

将线程从运行状态转为就绪状态

**让cpu重新调度，礼让不一定成功！**

```java
package Lesson04;

public class TestzYield {
    public static void main(String[] args) {
        MyYield myYield = new MyYield();

        new Thread(myYield,"a").start();
        new Thread(myYield,"b").start();
    }
}
class MyYield implements Runnable{
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+"线程开始执行");
        Thread.yield();//礼让
        System.out.println(Thread.currentThread().getName()+"线程停止执行");

    }
}
```

## 4.线程合并（Join）

插队，优先运行这个线程

```java
package Lesson04;
//join方法就是插队
public class TestJoin implements Runnable{
    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) {
            System.out.println("线程Vip来了"+i);
        }
    }

    public static void main(String[] args) {

        TestJoin testJoin = new TestJoin();
        Thread thread  = new Thread(testJoin);
        new Thread(testJoin).start();

        //主线程
        for (int i = 0; i < 500; i++) {
            if(i==200){
                try {
                    thread.join();//插队
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("main"+i);
        }
    }
}
```

## 5.线程状态（state）

```java
package Lesson04;

public class TestState {
    public static void main(String[] args) {
        Thread thread = new Thread(()->{
            for (int i = 0; i < 5; i++) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("=========");
        });

        Thread.State state = thread.getState();
        System.out.println(state);
        //观察启动
        thread.start();
        state = thread.getState();
        System.out.println(state);//Run

        while(state != Thread.State.TERMINATED){
            //只要线程不终止，就一直输出
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            state = thread.getState();//更新线程状态
            System.out.println(state);
        }
    }
}
```

# 10、线程优先级

getPriority().setPriority(int xxx)以下方法改变或者获取优先级

优先级的设定建议在start()调度前

```java
package Lesson04;

public class TestPriority {
    public static void main(String[] args) {
        //主线程默认优先级
        System.out.println(Thread.currentThread().getName()+"-->"+Thread.currentThread().getPriority());
        MyPriority myPriority = new MyPriority();

        Thread t1 = new Thread(myPriority);
        Thread t2 = new Thread(myPriority);
        Thread t3 = new Thread(myPriority);
        Thread t4 = new Thread(myPriority);
        Thread t5 = new Thread(myPriority);
        Thread t6 = new Thread(myPriority);

        //设置优先级再启动
        t1.start();

        t2.setPriority(1);
        t2.start();

        t3.setPriority(3);
        t3.start();

        t4.setPriority(Thread.MAX_PRIORITY);//==10
        t4.start();

       /* t5.setPriority(-1);
        t5.start();

        t6.setPriority(11);
        t6.start();*/
    }
}
    class MyPriority implements Runnable{
        @Override
        public void run() {
            System.out.println(Thread.currentThread().getName()+"-->"+Thread.currentThread().getPriority());
        }
    }
```

# 11、守护（daemon）线程

线程分为用户线程和守护线程

虚拟机必须确保用户线程执行完毕

虚拟机不用等待守护线程执行完毕

如：后台记录操作日志，监控内存，垃圾回收。

```java
package Lesson05;

//测试守护线程
//上帝守护你
public class TestDaemon {
    public static void main(String[] args) {
        God god = new God();
        U u = new U();


        Thread thread = new Thread(god);
        thread.setDaemon(true);//默认是false表示用户线程，正常的线程都是用户线程

        thread.start();

        new Thread(u).start();
    }
}
//上帝
class God implements Runnable{
    @Override
    public void run() {
        while (true){
            System.out.println("上帝保佑着你");
        }
    }
}
//你
class U implements Runnable{
    @Override
    public void run() {
        for (int i = 0; i < 36500; i++) {
            System.out.println("这是第："+i+"这一天你活着");
        }
        System.out.println("=========goodbye! world!===========");
    }
}
```

# 12、线程同步

### 1.并发

并发：同于i个对象被多个线程同时操作

处理多线程问题时，多个线程访问同一个对象，并且某些线程还想修改这个对象，这时候我们就需要线程同步，线程同步其实就是一种等待机制，多个需要同时访问此对象的线程进入这个对象的**等待池**形成队列，等待前面线程使用完毕，下一个线程再使用。

### 2、队列和锁

由于同一进程的多个线程共享同一块存储空间，再带来方便的同时，也带来了访问冲突的问题，为了保证数据在方法中被访问时的正确性，在访问时加入锁机制**synchronized**，当一个线程获得对象的排它锁，独占资源，其他线程必须等待，使用后释放锁即可，存在一下问题：

* 一个线程持有锁会导致其他所有需要此锁的线程挂起。
* 在多线程竞争下，加锁，释放锁会导致比较多的上下文切换和调度延时，引起性能问题。
* 如果一个优先级高的线程等待一个优先级低的线程释放锁，会导致优先级倒置，引起性能问题。

### 3、三大不安全的例子

不安全买票

```java
package Lesson05;

//不安全的线程。
//有负数有重复。
public class UnsafeBuyTicket {
    public static void main(String[] args) {
        BuyTicket station = new BuyTicket();

        new Thread(station,"你").start();
        new Thread(station,"我").start();
        new Thread(station,"黄牛").start();
    }
}
class BuyTicket implements Runnable{
    //票
    private int ticketNums = 10;
    boolean flag = true;//外部停止
    @Override
    public void run() {
        //买票
        while(flag){
            buy();
        }
    }
    private void buy(){
        //判断是否有票
        if(ticketNums <= 0){
            flag = false;
            return;
        }
        //模拟延时
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //买票
        System.out.println(Thread.currentThread().getName()+"拿到了"+ticketNums--);
    }
}
```

银行取款

```java
package Lesson05;

public class UnsafeBank {
    public static void main(String[] args) {
        //账户
        Account account = new Account(100,"结婚基金");

        Drawing you = new Drawing(account,50,"你");
        Drawing wife = new Drawing(account,100,"你老婆");

        you.start();
        wife.start();
    }
}
//账户
class Account{
    int money;//余额
    String name;//用户名
    public Account(int money,String name){
        this.money = money;
        this.name = name;
    }
}

//银行:模拟取款
class Drawing extends Thread{
    Account  account;//账户
    //取了多少钱
    int drawingMoney;
    //现在又多少钱
    int nowMoney;

    public Drawing(Account account,int drawingMoney,String name){
        super(name);
        this.account = account;
        this.drawingMoney = drawingMoney;
    }

    @Override
    public void run() {
        //判断有没有钱
        if(account.money-drawingMoney<0){
            System.out.println(Thread.currentThread().getName()+"的余额不足");
            return;
        }
        //模拟延迟，让你们俩人都进来
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //卡内余额 = 余额 - 取出的钱
        account.money = account.money - drawingMoney;
        //你手里的钱还剩
        nowMoney = nowMoney + drawingMoney;
        System.out.println(account.name+"余额为："+account.money);
        System.out.println(this.getName()+"手里的钱还剩："+nowMoney);
    }
}
```

不安全的集合

```java
package Lesson05;

import java.util.ArrayList;
import java.util.List;

//线程不安全的集合
public class UnsafeList {
    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        for (int i = 0; i < 10000; i++) {
            new Thread(()->{
                list.add(Thread.currentThread().getName());
            }).start();
        }
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(list.size());
    }

}
```

### 4、同步方法（synchronized）

由于我们可以通过private关键字来保证数据对象只能被方法访问，所以我们只需要针对方法提出一套机制，这套机制就是synchronized关键字，它包括俩种方法：synchronized方法和synchronized块。

```java
public synchronized void method(int args){}
```

同步代码块：

```java
synchronized（Obj）{}
```

synchronized方法控制对”对象“的访问，每个对象对应一把锁，每个synchronized方法都必须获得调用该方法的对象的锁才能够执行，否则线程会阻塞，方法一旦执行，就独占该锁，直到该方法返回才释放锁，后面被阻塞的线程才能获得这把锁，继续执行

**缺陷：若将一个大的方法申明为synchronized将会影响效率**

**方法里面需要修改的内容才需要锁，锁的太多，浪费资源**

```java
package Lesson05;

public class UnsafeBank {
    public static void main(String[] args) {
        //账户
        Account account = new Account(1000,"结婚基金");

        Drawing you = new Drawing(account,50,"你");
        Drawing wife = new Drawing(account,100,"你老婆");

        you.start();
        wife.start();
    }
}
//账户
class Account{
    int money;//余额
    String name;//用户名
    public Account(int money,String name){
        this.money = money;
        this.name = name;
    }
}

//银行:模拟取款
class Drawing extends Thread{
    Account  account;//账户
    //取了多少钱
    int drawingMoney;
    //现在又多少钱
    int nowMoney;

    public Drawing(Account account,int drawingMoney,String name){
        super(name);
        this.account = account;
        this.drawingMoney = drawingMoney;
    }

    @Override
    public void run() {
        //同步代码块
        synchronized (account){
            //判断有没有钱
            if(account.money-drawingMoney<0){
                System.out.println(Thread.currentThread().getName()+"的余额不足");
                return;
            }
            //模拟延迟，让你们俩人都进来
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //卡内余额 = 余额 - 取出的钱
            account.money = account.money - drawingMoney;
            //你手里的钱还剩
            nowMoney = nowMoney + drawingMoney;
            System.out.println(account.name+"余额为："+account.money);
            System.out.println(this.getName()+"手里的钱还剩："+nowMoney);
        }

    }
}
```

# 13、CopyOnWriteArrayyList

安全的集合

```java
package Lesson05;

import java.util.concurrent.CopyOnWriteArrayList;

//测试JUC安全类型的集合
public class TestJUC {
    public static void main(String[] args) {
        CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<String>();
        for (int i = 0; i < 10000; i++) {
            new Thread(()->{
                list.add(Thread.currentThread().getName());
            }).start();
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(list.size());
        }
        System.out.println(list.size());
    }
}
```

# 14、死锁

多个线程各自占有一些共享资源，并且互相等待其他线程占有的资源才能运行，而导致俩个或者多个线程都在等待对方释放资源，都停止执行的情形。某一个同步块同时拥有“**俩个以上对象的锁**，就可能会发生“死锁””的问题。

```java
package Lesson05;

import java.awt.*;

//死锁，多个线程互相抱着对方需要的资源，形成僵持
public class DeadLock {
    public static void main(String[] args) {
        Makeup g1 = new Makeup(0,"灰姑凉");
        Makeup g2 = new Makeup(1,"白雪公主");

        g1.start();
        g2.start() ;
    }
}
//口红
class Lipstick{

}
//镜子
class Mirror{

}
class Makeup extends Thread{
    //需要的资源资源只有一份，用static来保证
    static Lipstick lipstick = new Lipstick();
    static Mirror mirror = new Mirror();

    int choice;//选择
    String girlNmae;//使用化妆品的人

    Makeup(int choice, String girlNmae){
        this.choice = choice;
        this.girlNmae = girlNmae;
    }

    @Override
    public void run() {
        //化妆
        try {
            makeup();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    //化妆的方法，互相持有对方的锁，需要拿到对方的资源
    private void makeup() throws InterruptedException {
        if (choice == 0) {
            synchronized (lipstick) {//获得口红的锁
                System.out.println(this.girlNmae + "获得口红的锁");
                Thread.sleep(1000);

                synchronized (mirror) {//一秒钟后获得镜子
                    System.out.println(this.girlNmae + "获得镜子的锁");
                }
            }
        } else {
            synchronized (mirror) {//获得镜子的锁
                System.out.println(this.girlNmae + "获得镜子的锁");
                Thread.sleep(2000);

                synchronized (lipstick) {//二秒钟后获得口红
                    System.out.println(this.girlNmae + "获得口红的锁");
                }
            }
        }
    }
}
```

## 产生死锁的四个必要条件

1. 互斥条件：个资源每次只能被一个进程使用
2. 请求与保持条件：一个进程因请求资源而阻塞时，对已获得的资源保持不放
3. 不剥夺条件：进程以获得的资源，在未使用完前，不能强行剥夺
4. 循环等待条件：若干进程之间形成头尾相接的循环等待资源关系

# 15、Lock（锁）

从JDK5.0开始，Java提供了更强大的线程同步机制--通过显示定义同步锁对象实现同步。同步锁使用Lock对象充当

javautil.concurrent.locks。Lock接口是控制多个线程对共享资源进行访问的工具。锁提供了对共享资源的独占访问，每次只能有一个线程对Lock对象加锁，线程开始访问共享资源之前应先获得Lock对象。

ReentrantLock（可重入锁）类实现了Lock，它拥有与synchronized相同的并发性和内存语义，在实现线程安全的控制中，比较常用的是ReentrantLock，可以显示加锁、释放锁。

使用方法

```java
class A{
    private final ReentrantLock lock = new ReenTrantLock();
    public void m(){
        lock.lock();
        try{
            //保证线程安全的代码
        }
       finally{
           lock.unlock();
           //如果同步代码有异常，要将unlock()写入finally语句块
       }
    }
}
```

```java
package Lesson06;

import java.util.concurrent.locks.ReentrantLock;

//测试Lock锁
public class TestLoac {
    public static void main(String[] args) {
        TestLock2 testLoac2= new TestLock2();

        new Thread(testLoac2).start();
        new Thread(testLoac2).start();
        new Thread(testLoac2).start();
    }
}
class TestLock2 implements Runnable{
    int ticketNums = 10;
    //定义Lock锁
    private final ReentrantLock lcok = new ReentrantLock();
    @Override
    public void run() {
        while(true){

            try{
                lcok.lock();//加锁
                if(ticketNums>0){
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(ticketNums--);
                }
                else{
                    break;
                }
                Thread.sleep(100);
            }finally {
                //解锁
                lcok.unlock();
            }

        }
    }
}
```

## synchronized与Lock的对比

* Lock是显卡式锁（手动开启和光闭锁，记得光锁）synchronized是隐式锁，出了作用域自动释放。
* Lock只有代码块锁，synchronized有代码块锁和方法锁
* 使用Lock锁，JVM将花费较少的时间来调度线程，性能更好。并且具有更好的扩展性。（提供更多的子类）
* 优先使用顺序：Lock>同步代码块（已经进入方法体，分配了相应资源）>同步方法（在方法体之外）

# 16、线程通信

生产者-->数据缓存-->消费者

这是要给线程同步问题，生产者和消费者共享同一个资源，并且生产者和消费者相互依赖，互为条件

在生产者消费者问题中，仅有synchronized式不够的

synchronized可阻止并发更新同一个共享资源，实现了同步

synchronized不能用来实现不同线程之间的消息传递（通信）

Java提供了几个方法解决线程之间的通信问题

```java
Wait()//表示线程一直等待，知道其他线程通知，与sleep不同，会释放锁

Wait（long timeout）//指定等待毫秒数
  
notify()。//唤醒一个处于等待状态的线程
  
notifyAll()//唤醒同一个对象上所有调用wait()方法的线程，优先级别高的线程优先调度  
```

**注意：**

他们均为Object类的方法，都只能在同步方法或者同步代码块中使用，否则会抛出异常IIIegaIMonitorStateException。

## 解决方法1

并发协作模型车“生产者/消费者模式”--->管线法

生产者：负责生产数据模块（可能是方法，对象，线程，进程）

消费者：负责处理数据模块（可能是方法，对象，线程，进程）

缓冲区：消费者不能直接使用生产者的数据，他们之间有个缓冲区

**生产者将生产好的数据放入缓冲区，消费者冲缓冲区拿出数据**

前后台生产炸鸡模型

```java
package Lesson07;

//生产者/消费者模型--》利用管程法

//生产者，消费者，产品，缓冲区
public class TestPC {
    public static void main(String[] args) {
        SynContainer container = new SynContainer();

        new Productor(container).start();
        new Consumer(container).start();
    }
}

//生产者
class Productor extends Thread{
    SynContainer container;

   public Productor(SynContainer container){
       this.container = container;
   }
   //生产
    @Override
    public void run() {
        for (int i = 1; i < 10; i++) {
            try {
                container.push(new Chicken(i));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("生产了"+i+"只鸡");
        }
    }
}

//消费者
class Consumer extends Thread{
    SynContainer container;

    public Consumer(SynContainer container){
        this.container = container;
    }
    //消费


    @Override
    public void run() {
        for (int i = 1; i < 10; i++) {
            try {
                System.out.println("消费了："+container.pop().id+"只鸡");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

//产品
class Chicken{
    int id;//产品ID

    public Chicken(int id) {
        this.id = id;
    }
}

//缓冲区
class SynContainer{

    //容器大小
    Chicken[] chickens = new Chicken[10];
    //容器计数器
    int count = 0 ;

    //生产者放入产品
    public synchronized void push(Chicken chicken) throws InterruptedException {
        //如果容器满了，就要等待消费者消费
        if(count==chickens.length){
            //通知消费者消费，等待生产
            this.wait();
        }
        //如果没有满，就需要丢入产品
        chickens[count]=chicken;
        count++;

        //可以通知消费者消费
        this.notify();
    }

    //消费者消费产品
    public synchronized Chicken pop() throws InterruptedException {
        //等待十毫秒
        Thread.sleep(10);
        //判断能否消费
        if(count==0){
            //等待生产者生产，消费者等待
            this.wait();
        }

        //如果可以消费
        count--;
        Chicken chicken = chickens[count];

        //吃完了，通知生产者生产
        this.notify();

        return chicken;
    }
}
```

## 解决方式2

并发协作模型“生产者/消费者模式”---->信号灯法

定义一个boolea类型数据，用作标识，判断完以后反过来，用其判断什么时候等待、监听和唤醒

```java
package Lesson07;

//测试生产者消费者问题2：信号灯法：标志位解决
public class TestPC2 {
    public static void main(String[] args) {
        TV tv = new TV();
        new Player(tv).start();
        new Watcher(tv).start();

    }
}
//生产者：演员
class Player extends Thread{
    TV tv;
    public Player(TV tv){
        this.tv = tv;
    }

    @Override
    public void run() {
        for (int i = 1; i < 20; i++) {
            if(i%2==0){
                this.tv.play("电视剧");
            }else{
                this.tv.play("抖音");
            }
        }
    }
}

//消费者：观众
class Watcher extends Thread{
    TV tv;
    public Watcher(TV tv){
        this.tv = tv;
    }

    @Override
    public void run() {
        for (int i = 1; i < 20; i++) {
            tv.watch();
            System.out.println("观众在看电视");
        }
    }
}

//产品：节目
class TV{
   //演员表演，观众等待
   //观众观看，演员等待
    String voice;//表演的节目
    boolean flag = false;//标识

    //表演
    public synchronized void play (String voice){
        //演员等待
        if(flag){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("演员表演了："+voice);
        //通知观众观看
        this.notify();//通知唤醒

        this.voice = voice;

        this.flag = !this.flag;
    }

    //观众
    public synchronized void watch (){
        if(!flag){
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("观看了"+voice);
        //观看完，通知演员表演
        this.notifyAll();//通知唤醒
        this.flag = !this.flag;
    }
}
```

# 17、线程池

背景：经常创建和销毁、使用量特别大的资源，比如并发情况下的线程，对性能影响很大。

思路：提前创建好多个线程，放入线程池中，使用时直接获取，使用完放回池中，可以避免频繁创建销毁、实现充分利用。类似生活中的公共交通工具。

**好处：**

提高相应速度（减少了创建新线程的时间）

降低资源消耗（重复利用线程池中的线程，不需要每次都创建）

便于线程管理

```JAVA
corePoolSize//核心池的大小

maximumPoolSize//最大线程数
  
keepAliveTime//线程没有任务时最多保持多长时间后会终止
```

JDK5.0起提供了线程池相关API：ExecutorService和Executors

ExecutorService：真真的线程池接口。常见子类ThreadPoolExecutor

```java
void execute(Runnable command)://执行任务/命令，没有返回值，一般用来执行Runnable

<T>Future<T>submit(Callable<T>task)//执行任务，有返回值，一般又来执行Callable
  
void shutdown();闭连接池
```

Executors：工具类、线程池的工厂类，用于创建并返回不同类型的线程池
