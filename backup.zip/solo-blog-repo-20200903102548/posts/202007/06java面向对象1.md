title: 06java面向对象1
date: '2020-07-06 16:21:55'
updated: '2020-07-06 16:46:03'
tags: [Java, JavaSE]
permalink: /articles/2020/07/06/1594023715581.html
---
![](https://b3logfile.com/bing/20180907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 1、面向对象编程（oop）

面向过程思想

* 步骤清晰简单，第一步，第二部
* 面向过程适合处理一些较为简单的问题

面向对象思想

* 分类的思维模式，思考问题首先会解决问题需要那些分类，然后对这些分类进行单独思考。最后，才对某个分类下的细节进行面向过程的思索。
* 面向对象适合处理复杂的问题，适合处理需要多人协作的问题。

对于描述复杂的事物，为了从宏观上把握、从整体上合理分析，我们需要使用面向对象的思路来分析整个系统。但是，具体到微观操作，仍然需要面向过程的思路去处理。

面向对象编程（Object-Oriented Programming，oop）

面向对象编程的本质是：==以类的方式组织代码，以对象的组织（封装）数据。==

三大特性：封装，继承，多态

1.从认识论角度考虑是现有对象后有类。对象是具体的事物。类，是抽象的，是对对象的抽象。

2.从代码运行的角度考虑是先有类后有对象。类是对象的模块。

# 2、方法定义

### 1.方法的定义

修饰符

返回类型

break：跳出switch，结束循环和return的区别

方法名：==注意规范！见名知意==

参数列表：参数类型，参数名

异常抛出

```java
package Lesson02;

import java.io.IOException;

public class Demo01 {
    public static void main(String[] args) {

    }
    /**
     * 修饰符 返回值类型 方法名（***）{
     *     //方法体
     *     return 返回值；结束方法，返回一个结果。
     * }
     */
    public String sayHello(){
        return "hello world";
    }
    public int max(int a ,int b ){
        return a>b?a:b;//三元运算符
    }
    //抛出异常的方法
    public void readFile(String file)throws IOException{

    }
}
```

# 3、方法的调用

### 1.静态方法和非静态方法

如果是static的就可以通过类名直接调用

假如不是，就需要实例化类名进行调用

```java
package Lesson02;

public class Demo02 {
    public static void main(String[] args) {
        //实例化这个类 new
        //对象类型，对象名 = 对象值
        Student student = new Student();
        new Student().say();
    }

}

package Lesson02;

public class Student {
    //方法
    public void say(){
        System.out.println("学生说话了");
    }
}

```

类名调用通常错误

```java
 //static 是和类一起加载的
    public static void a(){
        b();
    }
    //类实例化之后才会存在，所以这时候a是调用还不存在的方法b，所以会报错
    public void b(){

    }
```

### 2.形参和实参

```jade
package Lesson02;

public class Demo03 {
    public static void main(String[] args) {
        //实际参数和形式参数的类型要对！

        //
        int add = new Demo03().add(1, 2);
        System.out.println(add);
        new Demo03().add(1,2);
        System.out.println(add2(1,2));

    }
    public int add(int a,int b){
        return a+b;
    }
    public static int add2(int a,int b){
        return a+b;
    }
}
```

### 3.值传递和引用传递

#### 1.值传递

```java
package Lesson02;

//值传递
public class Demo04 {
    public static void main(String[] args) {
        int a = 1;
        System.out.println(a);//1

        Demo04.change(a);

        System.out.println(a);//输出还是1
    }
    //返回值为空
    public static  void change(int a){
        a = 10;
    }
}
```

#### 2.引用传递

```java
package Lesson02;

//引用传递：对象，本质还是值传递

//对象，和内存。
public class Demo05 {
    public static void main(String[] args) {
        Person person = new Person();
        System.out.println(person.name);//null

        Demo05.change(person);
        System.out.println(person.name);//坏银

    }
    public static void change(Person person){
        //person是一个对象，指向的-->Person person = new Person（）；这是一个具体的人，可以改变属性！
        person.name = "坏银2";
    }
}
//定义了一个person类，有一个属性：name
class Person{
    String name = "坏银1";
}
```

### 4.this关键字

放在继承和多态里面讲。

# 4、类与对象的关系

==类是一种抽象的数据类型，它是对某一类事物整体描述/定义，但是并不能代表某一个具体的事物==

==对象是抽象概念的具体实例==

* 使用new关键字创建对象

使用new关键字 创建的时候，除了分配内存空间外，还会给创建好的对象进行默认的初始化以及对类中构造器的调用。

主方法

```java
package Lesson03;


//一个项目只存在一个main方法
public class Application {
    public static void main(String[] args) {
        //类：是抽象的，实例化
        //类实例化后返回一个自己的对象
        //student对象就是一个Student类的具体实例
        Student xiaoming = new Student();
        Student xiaohong = new Student();

        xiaoming.name = "小明";
        xiaoming.age = 3;
        xiaohong.name = "小红";
        xiaohong.age = 3;

        System.out.println(xiaoming.name);
        System.out.println(xiaoming.age);
        System.out.println(xiaohong.name);
        System.out.println(xiaohong.age);
    }
}
```

学生类

```java
package Lesson03;

public class Student {
    //属性：字段
    String name;//numm
    int age;//0

    //方法
    public void study() {
        System.out.println(this.name + "在学习");
    }
}
```

# 5、构造器

类中的构造器也称为构造方法，是在进行创建对象的时候必须调用的，并且构造器有一下俩个特点：

* 必须和类名字相同。
* 必须没有返回类型，也不能写void

```java
package Lesson03;

//一个项目只存在一个main方法
public class Application {
    public static void main(String[] args) {
        //new
        // 实例化对象
        Person person = new Person();

        System.out.println(person.name);//坏银
    }
}
class Person {
    //一个类什么也不写，也会存在一个构造器
    //显示定义构造器

    String name;

    //实例化初始值，默认会生成一个无参构造
    //使用new关键字，本质是在调用构造器，必须要有构造器
    //初始化值
    public Person(){
        this.name = "坏银";
    }

    //有参构造:一旦定义了有参构造，无参就必须显示定义
    public Person(String name){
        this.name = name ;
    }
}
```

# 6、创建对象内存分析

```java
package Lesson04;

public class Application {
    public static void main(String[] args) {
        Pet dog = new Pet();
        dog.name="旺财";
        dog.age = 3;
        dog.shout();

        System.out.println(dog.age);
        System.out.println(dog.name);

        Pet cat = new Pet();
    }
}
```

```java
package Lesson04;

public class Pet {
    public String name;
    public int age;
    public void shout(){
        System.out.println("叫了一声");
    }
}
```

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java学习/6.jpg)



# 7、小结类与对象

```java
package Lesson04;

public class All {
    /*
    *   1. 类与对象
    *   类是一个模板：抽象，对象是一个具体实例
    *   2. 方法
    *   定义、调用！
    *
    *   3.对应的引用
    *   引用类型： 基本类型（8）
    *   对象是通过引用来操作的。栈-->堆
    *
    *   4.属性：字段Field 成员变量
    *   默认初始化
    *   数字：0 0.0
    *   char： u0000
    *   Boolean：false
    *   引用： null
    *   修饰符 属性类型 属性名 = 属性值！
    *
    *   5. 对象的创建与使用、
    *   - 必须使用new 关键字创造对象 ，构造器 Person huaiyin = new Person();
    *   - 对象的属性 huaiyin.name
    *   - 对象的方法 huaiyin.sleep();
    *
    *   类：
    *   静态的属性 属性
    *   动态的行为 方法
    */

}
```
