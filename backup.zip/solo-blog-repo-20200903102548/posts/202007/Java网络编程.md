title: Java网络编程
date: '2020-07-24 16:51:05'
updated: '2020-08-04 11:03:40'
tags: [Java, JavaSE]
permalink: /articles/2020/07/24/1595580665272.html
---
![](https://b3logfile.com/bing/20181219.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 网络编程

## 1.1、 概述

**信件：**

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java网络编程/1.jpg)

**计算机网络：**

计算机网络是指==地理位置不同==的具有独立功能的多台计算机极其外部设备，通过通信线路连接起来，在网络操作系统，网络管理软件和网络通信协议的管理和协调下，实现资源共享和信息传递的计算机系统。

**网络编程的目的：**

电台...传播和交流信息，数据交换。通信。

**想要达到的效果是什么：**

1. 如何定位网络上的一台主机。IP：端口号，定位这个计算机上的某个资源。
2. 找到这个主机，如何传输数据呢？

## 1.2、网络通信的要素

如何实现网络通信？

通信双方的地址：

* IP
* 端口

**规则：网络通信的协议**

TCP/IP参考模型

![](https://cdn.jsdelivr.net/gh/lmlx66/img/java网络编程/3.jpg)

小结：

1.网络编程中的俩个问题

* 如何准确的定位到网络上的一台或者多台主机
* 找到主机之后如何进行通信

2.网络编程中的要素

* IP和端口号
* 网络通信写协议：UDP、TCP

3.万物皆对象

## 1.3、IP

ip地址：InetAddress

* 唯一定位一台网络上的计算机
* 127.0.0.1：本机localhost

ip地址的分类

* ipv4/ipv6
  * ipv4：127.0.0.1,四个字节组成。0~255，42亿个；
  * ipv6：128位。8个无符号整数表示的！
* 公网-私网
* 域名：记忆IP问题！
  * IP：www.lmlx66.top

```java
package Lesson01;

import java.net.InetAddress;
import java.net.UnknownHostException;

//测试IP
public class TestInetAddress {
    public static void main(String[] args) throws UnknownHostException {
        InetAddress inetAddress1 = InetAddress.getByName("127.0.0.1");
        System.out.println(inetAddress1);
        InetAddress inetAddress2 = InetAddress.getByName("localhost");
        System.out.println(inetAddress2);
        InetAddress inetAddress3 = InetAddress.getLocalHost();
        System.out.println(inetAddress3);

        InetAddress inetAddress4 = InetAddress.getByName("www.baidu.com");
        System.out.println(inetAddress4);

        //常用方法
        System.out.println(inetAddress2.getAddress());
        System.out.println(inetAddress2.getCanonicalHostName());
        System.out.println(inetAddress2.getHostAddress());
        System.out.println(inetAddress2.getHostName());
    }
}
```

## 1.4、端口

·端口表示计算机上的一个程序进程：

* 不同的进程，有不同的端口号！
* 被规定：0~65535
* TCP 、UDP：65535*2
* 端口分类
  * 0~1023
    * HTTP：80
    * HTTPS：443
    * FTP：21
    * Telent：23
  * 程序注册端口：2014~49151，分配用户给
    * Tomact：8080
    * MySQL：3306
    * Oracle：1521
  * 动态、私有49152~65535

> netstat -ano //查找所有的端口
>
> netstat -ano|findstr“5900”//查看指令的端口
>
> tasklist|findstr"端口"//查看开放的进程

## 1.5、通信协议

协议：约定，就像我们说的普通话。

**网路通信协议**速率，传输码率，代码结构，传输控制...

分层

**TCP/IP协议簇：实际上是一组协议**

TCP：用户传输协议

UDP：用户数据报协议

### TCP UDP 对比

TCP：打电话

* 连接，稳定
* 三次握手，四次挥手

```
最少需要三次，保证稳定连接
A：你瞅啥？
B：瞅你咋地
A：干你

断开
A：我要走了
B：你真的要走了吗？
B：你真的真的要走了吗？
A：你好，是的
```

* 客户端、服务端
* 传输完成，释放连接，效率低

UDP：发短信

* 不连接，不稳定
* 客户端、服务端：没有明确的界限
* 不管有没有准备好，都可以发给你

## 1.6、TCP

**客户端:**

1. 连接服务器 Socket
2. 发送消息

```java
package Lesson02;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

//客户端
public class TcpCliet {
    public static void main(String[] args) throws IOException {

        //1.知道服务器的地址
        InetAddress serverIP = InetAddress.getByName("127.0.0.1");
        //2.端口号
        int port = 9999;
        //3.创建一个socket连接
        Socket socket = new Socket(serverIP,port);
        //4.发送消息：IO流
        OutputStream os = socket.getOutputStream();
        os.write("你好，我是坏银".getBytes());

        if(os!=null){
            os.close();
        }
        if(socket!=null) {
            socket.close();
        }
    }
}
```

**服务器:**

1. 建立服务端口 ServerSocket
2. 等待用户连接 accept
3. 接受用户消息

```java
package Lesson02;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

//服务端
public class TcpServer {
    public static void main(String[] args) throws IOException {
        Socket socket = null;
        ByteArrayOutputStream baos= null;
        InputStream is= null;
        //1.知道一个地址
        ServerSocket serverSocket = new ServerSocket(9999);
            //2.等待客户端连接
            socket = serverSocket.accept();

            //3.读取客户端的消息
            is = socket.getInputStream();

            //管道流
            baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;
            while((len=is.read(buffer))!=-1){
                baos.write(buffer,0,len);
            }
            System.out.println(baos.toString());
        //关闭资源
        if (baos != null) {
            baos.close();
        }
        if(is!=null){
            is.close();
        }
        if(socket!=null){
            socket.close();
        }
        if(serverSocket!=null){
            serverSocket.close();
        }
    }
}
```

## 1.7、文件上传

服务端

```java
package Lesson03;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws IOException {
        //1.创建服务
        ServerSocket serverSocket = new ServerSocket(9000);
        //2.监听客户端连接
        Socket socket =serverSocket.accept();//阻塞性监听，会一直等待客户端。连接以后，就关闭了
        //3.获取输入流
        InputStream is = socket.getInputStream();
        //4.文件输出
        FileOutputStream fos = new FileOutputStream(new File("receive.jpg"));
        byte[] buffer = new byte[1024];
        int len;
        while ((len=is.read(buffer))!=-1){
            fos.write(buffer,0,len);
        }


       //通知客户端我接受完毕
        OutputStream os = socket.getOutputStream();
        os.write("==== 接受完毕啦！====".getBytes());

        //关闭资源
        fos.close();
        is.close();
        socket.close();
        serverSocket.close();
    }
}
```

客户端

```java
package Lesson03;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.SocketHandler;

public class TcpClient {

    public static void main(String[] args) throws IOException {
        //1.创建一个socket连接
        Socket socket = new Socket(InetAddress.getByName("127.0.0.1"),9000);
        //2.创建一个输出流
        OutputStream os = socket.getOutputStream();
        //3.读取文件
        FileInputStream fis = new FileInputStream(String.valueOf(new File("E:/JAVA/UDP/img/3.jpg")));
        //4.写出文件
        byte[] buffer = new byte[1024];
        int len;
        while((len=fis.read(buffer))!=-1){
           os.write(buffer,0,len);
            System.out.println("发送成功");
        }

        //通知客户端，结束了
        socket.shutdownOutput();


        //确定服务器接受完毕，才能够断开连接
        InputStream inputStream = socket.getInputStream();//包
        ByteArrayOutputStream baos = new ByteArrayOutputStream();//管道
        byte[] buffer2 = new byte[1024];
        int len2;
        while ((len2=inputStream.read(buffer2))!=-1){//包大小，进入缓冲区
            baos.write(buffer2,0,len2);//管道传输
        }
        System.out.println(baos.toString());

        //5.关闭资源
        fis.close();
        os.close();
        socket.close();
        buffer.clone();
        inputStream.close();
        baos.close();
        buffer2.clone();
    }
}
```
