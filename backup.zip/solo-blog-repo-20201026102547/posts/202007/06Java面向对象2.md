title: 06Java面向对象2
date: '2020-07-07 10:12:01'
updated: '2020-07-12 18:43:53'
tags: [Java, JavaSE]
permalink: /articles/2020/07/07/1594087921646.html
---
# 1、封装

该露的露，该藏的藏

我们程序设计追求“高内聚，低耦合”。高内聚就是类的内部数据操作细节自己完成，不允许外部干涉；低耦合:仅暴露少量的方法给外部使用。

封装（数据的隐藏）

实现

```java
package Lesson05;
/*
1. 提高程序的安全性，保护数据
2. 隐藏代码实现细节
3. 统一接口
4. 提高系统可维护性
*/
public class Application {
    public static void main(String[] args) {
        Student s1 = new Student();

        s1.setName("坏银");
        System.out.println(s1.getName());

        s1.setAge(999);//不合法的
        System.out.println(s1.getAge());
    }
}
```

类

```java
package Lesson05;

//类 private:私有
public class Student {

    //属性私有
    private String name;//名字
    private int id;//学号
    private char sex;//性别
    private  int age;//年龄

    //提供一些可以操作这些属性的方法
    //提供一些public的get、set方法

    //get获得这个数据
    public String getName(){
        return this.name;
    }
    //set 给这个数据设置值
    public void setName(String name){
        this.name = name;
    }
    //alt + insert
    //点击getter和setter可以快速创建
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if(age>120||age<0){
            this.age = 3;
        }
        else{
            this.age = age;
        }
    }
}
```

# 2、继承

继承的本质是对某一批类的抽象，从而实现对现实世界更好的建模。

==extands==的意思是“扩展”。子类是父类的扩展。

Java中类只有单继承，没有多继承！

继承是类与类之间的一种关系。除此之外，类和类之间的关系还有依赖、组合、聚合等。

继承关系的俩个类，一个为子类（派生类），一个为父类（基类）。子类继承父类，使用关键字extends来表示。

子类和父类之间，从意义上讲应该具有“is a”的关系。

人类

```java
package Lesson06;

//子类继承了父类，就会拥有父类的全部方法！
//Ctrl + H 可以打开继承树
//在Java中，所有的类，都默认继承object类
public class Person {
    //public
    //private
    public void say(){
        System.out.println("说了一句话");
    }
}

```

学生类继承人类

```java
package Lesson06;

public class Sutdent extends Person{

}
```

老师类继承人类

```java
package Lesson06;

public class Teacher extends  Person{

}
```

运行

```java
package Lesson06;

import Lesson02.Student;

public class Application {
    public static void main(String[] args) {
        Student student = new Student();
        student.say();
    }

}
```

# 3、super详解

人类

```java
package Lesson07;

public class Person {
    protected String name = "父类";

    public Person() {
        System.out.println("Person无参构造执行");
    }

    public void print(){
        System.out.println("person");
    }
}
```

学生类

```java
package Lesson07;

public class Student extends Person{
    private String name = "huaiyin";

    public Student() {
        //隐藏代码，调用了父类的无参构造
        super();//调用父类的构造器，必须要在子类构造器的第一行
        System.out.println("Student无参构造执行了");
    }

    public void print(){
        System.out.println("Student");
    }
    public void test1(){
        print();
        this.print();
        super.print();
    }
    public void test(String name){
        System.out.println(name);//坏银
        System.out.println(this.name);//huaiyin
        System.out.println(super.name);//父类
    }
}
```

运行类

```java
package Lesson07;

//私有的东西无法被继承
public class Application {
    public static void main(String[] args) {
        Student student = new Student();
        student.test("坏银");
        student.test1();
    }
}
```

## 总结

1. super调用父类的第一个点，必须在构造方法的第一个。
2. super须只能出现在子类的方法或者构造方法中。
3. super和this不能同时调用构造方法！

Vs this：

代表的对象不同：

> this：本身调用者这个对象
>
> super：代表父类对象的应用
>
> 前提
>
> this：没有继承也可以使用
>
> super；只能在继承条件才可以使用
>
> 构造方法
>
> this（）；本类的构造
>
> super（）；父类的构造！

# 4、方法的重写

B类

```java
package Lesson08;
//重写都是方法的重写，和属性无光
public class B {
    public void test(){
        System.out.println("B=>test()");
    }
}
```

A类继承B类

```java
package Lesson08;

public class A extends B {

    /*
    第一次输出A和B的方法
    public static void test(){
        System.out.println("A=>test()");
    第一次中B中的为静态方法
    public class B {
    public static void test(){
        System.out.println("B=>test()");
    }
     */

    @Override//重写的意思，这是一个有功能的注解。
    public void test(){
        System.out.println("A=>test()");
    }
}
```

实现类

```java
package Lesson08;
/*
*   只有是非静态方法才可以重写！
*/
public class Application {
    public static void main(String[] args) {
        //静态的方法和非静态的方法区别很大。
        //静态方法：方法的调用只和左边的类型有关，也就是定义的数据类型有关。
        A a = new A();
        a.test();//A

        //父类的引用指向了子类
        B b = new A();
        b.test();//B
    }
}
```

## 总结

重写：需要有继承关系，子类重写父类的方法!

1. 方法名必须相同
2. 参数列表必须相同。
3. 修饰符：范围可以扩大。   public>protected>defauult>private
4. 抛出异常：范围可以被缩小，但是不能扩大

重写，子类的方法和父类必须一致：方法体不同！

为什么需要重写？

1. 父类的功能，子类不一定需要或者不一定满足。（动物类，狗和猫叫声音不一样）
2. Alt + insert ; override;

# 5、多态

即同一个方法可以根据发送的对象不同而采用多种不同的行为方式。

一个对象的实际类型是确定的，但可以指向对象的引用的类型有很多。

多态的存在条件：

* 有继承关系
* 子类重写父类的方法
* 父类引用指向子类对象

人类

```java
package Lesson09;

public class Person {

    public void run(){
        System.out.println("Run");
    }
}
```

学生类

```java
package Lesson09;

import javax.swing.*;

public class Student extends Person{

    @Override
    public void run() {
        System.out.println("som");
    }
    public void eat(){
        System.out.println("eat");
    }
}
```

执行类

```java
package Lesson09;

public class Application {

    public static void main(String[] args) {
        //一个对象的实际类型是确定的
        //new Student();
        //new Person();

        //可以子项的引用类型就不确定了：父类的引用指向子类

        //Student 能调用的方法都是自己的或者继承父类的。
        Student s1 = new Student();
        //Person 父类型，可以指向子类，但不能调用子类独有的方法。
        Person s2 = new Student();
        Object s3 = new Student();

        s2.run();//子类重写了父类的方法，执行子类的方法
        s1.run();

        //能执行哪些方法，主要是看对象右边的类型，和右边的关系不大！
        //s2.eat();
        //怎么才可以执行呢？向下转换
        ((Student)s2).eat();
        s1.eat();
    }
}
```

## 多态注意事项：

1. 多态是方法的多态，属性没有多态
2. 父类的子类，有联系！类型转换异常！ClassCastException！
3. 存在条件：继承关系，方法需要重写。父类的引用，指向子类对象!

```java
Father f1 = new Son();
```

4. 不能被重写的方法

* static 方法，署于类，它不属于实例。
* final 常量；
* private 方法。
